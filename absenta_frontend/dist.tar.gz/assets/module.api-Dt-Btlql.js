import{O as e}from"./main-CUbVbX1E.js";async function t(){return e("get","/billing/modules/public")}export{t as g};
