import{bG as i}from"./main-CUbVbX1E.js";function e(){const{confirm:o,setConfirmLoading:n}=i();return Object.assign(s=>o(s),{setLoading:n})}export{e as u};
