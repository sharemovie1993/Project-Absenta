import{i as c}from"./main-CUbVbX1E.js";import{z as h}from"./vendor-ui-libs-Cq6TYVVI.js";const w=async()=>{try{const t=await c.get("/cooperative/settings");if(t.data&&t.data.data){const e=t.data.data;return{cooperative_name:e.cooperative_name||"KOPERASI SEKOLAH",cooperative_legal_no:e.cooperative_legal_no||"",cooperative_address:e.cooperative_address||"",cooperative_phone:e.cooperative_phone||"",cooperative_email:e.cooperative_email||"",cooperative_website:e.cooperative_website||"",cooperative_logo_url:e.cooperative_logo_url||"",cooperative_default_interest_rate:e.cooperative_default_interest_rate||"",signatures:{bendahara:e.signatures?.bendahara||"........................",ketua:e.signatures?.ketua||"........................",kepsek:e.signatures?.kepsek||"........................"}}}}catch(t){console.warn("Failed to load coop settings for document utility",t)}return{cooperative_name:"KOPERASI SEKOLAH",cooperative_legal_no:"",cooperative_address:"",cooperative_phone:"",cooperative_email:"",cooperative_website:"",cooperative_logo_url:"",cooperative_default_interest_rate:"",signatures:{bendahara:"........................",ketua:"........................",kepsek:"........................"}}},b=async t=>{try{let e;if(t.startsWith("/")||t.startsWith(window.location.origin)||t.includes(window.location.host)){let r=t;if(t.startsWith("http://")||t.startsWith("https://"))try{const o=new URL(t);r=o.pathname+o.search}catch{r=t}e=await(await fetch(window.location.origin+r)).blob()}else e=(await c.get(`/cooperative/settings/logo-proxy?url=${encodeURIComponent(t)}`,{responseType:"blob"})).data;return new Promise(r=>{const n=new FileReader;n.onloadend=()=>{const o=new Image;o.onload=()=>{const i=document.createElement("canvas"),s=o.naturalWidth||o.width||200,d=o.naturalHeight||o.height||200;i.width=s,i.height=d;const l=i.getContext("2d");l?(l.fillStyle="#FFFFFF",l.fillRect(0,0,s,d),l.drawImage(o,0,0,s,d),r(i.toDataURL("image/png"))):r(n.result)},o.onerror=()=>r(null),o.src=n.result},n.readAsDataURL(e)})}catch(e){return console.warn("Failed to load image via proxy or direct fetch",e),null}},m=t=>{if(!t)return"-";const e=new Date(t);return isNaN(e.getTime())?"-":`${String(e.getDate()).padStart(2,"0")} ${["Januari","Februari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"][e.getMonth()]} ${e.getFullYear()}`},v=t=>{if(!t)return"-";const e=new Date(t);if(isNaN(e.getTime()))return"-";const a=m(e),r=String(e.getHours()).padStart(2,"0"),n=String(e.getMinutes()).padStart(2,"0");return`${a} ${r}:${n}`},p=t=>{const e=["","Satu","Dua","Tiga","Empat","Lima","Enam","Tujuh","Delapan","Sembilan","Sepuluh","Sebelas"],a=Math.floor(Math.abs(t));return a<12?e[a]:a<20?p(a-10)+" Belas":a<100?p(a/10)+" Puluh "+p(a%10):a<200?"Seratus "+p(a-100):a<1e3?p(a/100)+" Ratus "+p(a%100):a<2e3?"Seribu "+p(a-1e3):a<1e6?p(a/1e3)+" Ribu "+p(a%1e3):a<1e9?p(a/1e6)+" Juta "+p(a%1e6):String(a)},x=(t,e,a,r=15,n=195)=>{let i=r;if(a){const d=a.startsWith("data:image/png")?"PNG":"JPEG";t.addImage(a,d,15,i-7,18,18)}else{t.setFillColor(79,70,229),t.circle(24,i,9,"F"),t.setDrawColor(255,255,255),t.setLineWidth(.5),t.circle(24,i,8,"D"),t.setFont("Helvetica","bold"),t.setFontSize(10),t.setTextColor(255,255,255);const d=e.cooperative_name.trim().charAt(0)||"K";t.text(d,22.5,i+3.5)}t.setFont("Helvetica","bold"),t.setFontSize(13),t.setTextColor(30,58,138),t.text(e.cooperative_name.toUpperCase(),38,i),t.setFont("Helvetica","normal"),t.setFontSize(9),t.setTextColor(71,85,105),e.cooperative_legal_no&&(i+=4.5,t.text(`Badan Hukum: ${e.cooperative_legal_no}`,38,i)),e.cooperative_address&&(i+=4.5,t.text(e.cooperative_address,38,i,{maxWidth:n-38}));const s=[];return e.cooperative_phone&&s.push(`Telp: ${e.cooperative_phone}`),e.cooperative_email&&s.push(`Email: ${e.cooperative_email}`),e.cooperative_website&&s.push(`Web: ${e.cooperative_website}`),s.length>0&&(i+=4.5,t.text(s.join(" | "),38,i)),i+=6,t.setDrawColor(79,70,229),t.setLineWidth(.8),t.line(15,i,n,i),t.setDrawColor(148,163,184),t.setLineWidth(.2),t.line(15,i+.8,n,i+.8),i+8},f=(t,e,a,r="",n="Mandiri")=>{if(!t)return;const o=window.open("","_blank","width=400,height=600");if(!o){h.error("Gagal membuka halaman cetak. Periksa blocker popup browser Anda.");return}const i=(t.items||[]).map(l=>`
      <tr>
          <td style="padding: 4px 0; max-width: 100px; overflow: hidden; text-overflow: ellipsis; white-space: nowrap;">
              ${l.product?.name||"Produk"}
          </td>
          <td style="text-align: center; padding: 4px 0; white-space: nowrap; width: 30px;">${l.quantity}</td>
          <td style="text-align: right; padding: 4px 0; white-space: nowrap; width: 70px;">Rp ${(Number(l.price)*l.quantity).toLocaleString("id-ID")}</td>
      </tr>
  `).join(""),s=a.length>20?a.slice(0,20)+"...":a,d=r?`(${r})`:"";o.document.write(`
      <html>
      <head>
          <title>Struk Pembelian #${t.id.slice(0,8)}</title>
          <style>
              @page { size: 58mm auto; margin: 0; }
              body, table, th, td, p, div {
                  font-family: 'Courier New', Courier, monospace;
                  font-size: 10px;
                  line-height: 1.3;
                  color: #000;
              }
              body {
                  width: 58mm;
                  margin: 0;
                  padding: 8px;
                  box-sizing: border-box;
              }
              .center { text-align: center; }
              .divider { border-bottom: 1px dashed #000; margin: 6px 0; }
              table { width: 100%; border-collapse: collapse; }
              th, td { font-size: 10px; }
              .right { text-align: right; }
              .bold { font-weight: bold; }
          </style>
      </head>
      <body>
           <div class="center">
                <h3 style="margin: 0; font-size: 12px; font-weight: bold; text-transform: uppercase;">${e.cooperative_name||"KOPERASI SEKOLAH"}</h3>
                <p style="margin: 2px 0; font-size: 9px;">${e.cooperative_address||"Kantin & Minimarket"}</p>
                ${e.cooperative_phone?`<p style="margin: 2px 0; font-size: 9px;">Telp: ${e.cooperative_phone}</p>`:""}
                <p style="margin: 2px 0; font-size: 9px;">${new Date(t.date).toLocaleString("id-ID")}</p>
            </div>
            <div class="divider"></div>
            <div>
                <p style="margin: 2px 0;">No Struk: #${t.id.slice(0,8)}</p>
                <p style="margin: 2px 0;">Pembeli : ${s} ${d}</p>
                <p style="margin: 2px 0;">Kasir   : ${n}</p>
            </div>
            <div class="divider"></div>
            <table>
                <thead>
                    <tr style="border-bottom: 1px dashed #000;">
                        <th style="text-align: left; padding-bottom: 4px; width: 100px;">Item</th>
                        <th style="text-align: center; padding-bottom: 4px; width: 30px;">Qty</th>
                        <th style="text-align: right; padding-bottom: 4px; width: 70px;">Total</th>
                    </tr>
                </thead>
                <tbody>
                    ${i}
                </tbody>
            </table>
            <div class="divider"></div>
            <table>
                ${t.discount&&Number(t.discount)>0?`
                <tr>
                    <td style="white-space: nowrap;">DISKON VOUCHER (${t.voucherCode})</td>
                    <td class="right" style="white-space: nowrap;">-Rp ${Number(t.discount).toLocaleString("id-ID")}</td>
                </tr>
                `:""}
                <tr>
                    <td class="bold" style="white-space: nowrap;">TOTAL</td>
                    <td class="right bold" style="white-space: nowrap;">Rp ${Number(t.total).toLocaleString("id-ID")}</td>
                </tr>
                <tr>
                    <td style="white-space: nowrap;">Metode Bayar</td>
                    <td class="right" style="white-space: nowrap;">${t.paymentMethod==="SAVING"?"Tabungan":"Tunai"}</td>
                </tr>
                ${t.paymentMethod==="CASH"?`
                <tr>
                    <td style="white-space: nowrap;">Bayar</td>
                    <td class="right" style="white-space: nowrap;">Rp ${Number(t.cashAmount||0).toLocaleString("id-ID")}</td>
                </tr>
                <tr>
                    <td style="white-space: nowrap;">Kembali</td>
                    <td class="right" style="white-space: nowrap;">Rp ${Number(t.changeAmount||0).toLocaleString("id-ID")}</td>
                </tr>
                `:t.member?`
                <tr>
                    <td style="white-space: nowrap;">Sisa Saldo</td>
                    <td class="right" style="white-space: nowrap;">Rp ${(t.member.sukarelaBalance-Number(t.total)).toLocaleString("id-ID")}</td>
                </tr>
                `:""}
            </table>
            ${(t.memberId||t.member)&&t.total>=1e4?`
            <div class="divider"></div>
            <div class="center" style="margin: 8px 0; font-weight: bold; border: 1px dashed #000; padding: 4px;">
                POIN DIPEROLEH: +${Math.floor(t.total/1e4)} Poin
            </div>
            `:""}
            <div class="divider"></div>
            <div class="center" style="margin-top: 10px;">
                <p style="margin: 0;">Terima Kasih</p>
                <p style="margin: 2px 0; font-size: 8px;">Selamat Belanja Kembali</p>
            </div>
            <script>
                window.onload = function() {
                    window.print();
                    setTimeout(function() { window.close(); }, 500);
                }
            <\/script>
       </body>
       </html>
  `),o.document.close()};export{m as a,v as b,p as c,x as d,w as f,b as g,f as p};
