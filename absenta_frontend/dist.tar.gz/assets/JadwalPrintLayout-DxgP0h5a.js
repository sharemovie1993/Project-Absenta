import{j as t}from"./vendor-query-BhgjtrJT.js";import{l as g}from"./vendor-react-BFl1Q6nk.js";import{f as j}from"./vendor-date-_usxnDfA.js";import{r as y}from"./index-B6EsGKGr.js";import"./vendor-ui-libs-Cq6TYVVI.js";const S=["SENIN","SELASA","RABU","KAMIS","JUMAT","SABTU"],w={SENIN:"Se",SELASA:"Se",RABU:"Ra",KAMIS:"Ka",JUMAT:"Ju",SABTU:"Sa"},d=Array.from({length:10},(i,s)=>s+1),p={1:"07:00 - 07:45",2:"07:45 - 08:30",3:"08:30 - 09:15",4:"09:35 - 10:20",5:"10:20 - 11:05",6:"11:05 - 11:50",7:"12:30 - 13:15",8:"13:15 - 14:00",9:"14:00 - 14:45",10:"14:45 - 15:30"},U=({jadwal:i,guruName:s,subjectName:m,isPrinting:h})=>{if(!h)return null;const x=(e,n)=>{const a=p[n].split(" - "),r=a[0],o=a[1];return i.find(l=>{if(l.hari!==e)return!1;const c=l.jam_mulai.split(":").slice(0,2).join(":");return c>=r&&c<o})},f=m||Array.from(new Set(i.map(e=>e.Mapel?.nama_mapel).filter(Boolean)))[0]||"-",u=s||Array.from(new Set(i.map(e=>e.Guru?.User?.full_name).filter(Boolean)))[0]||"-",b=t.jsxs("div",{className:"absenta-print-container",children:[t.jsx("style",{children:`
          /* Sembunyikan kontainer di layar biasa */
          .absenta-print-container {
            display: none;
          }

          @media print {
            /* Pengaturan Kertas */
            @page {
              size: landscape;
              margin: 10mm;
            }

            /* Sembunyikan elemen utama aplikasi (di luar Portal) */
            body > *:not(.absenta-print-container) {
              display: none !important;
            }

            /* Tampilkan kontainer print */
            .absenta-print-container {
              display: block !important;
              position: absolute;
              top: 0;
              left: 0;
              width: 100%;
              background: white !important;
              color: black !important;
            }

            body {
              background: white !important;
              -webkit-print-color-adjust: exact !important;
              print-color-adjust: exact !important;
            }

            .asc-table {
              width: 100%;
              border-collapse: collapse;
              table-layout: fixed;
              border: 2px solid #000;
              background: white !important;
            }
            .asc-table th, .asc-table td {
              border: 1px solid #000;
              padding: 2px;
              height: 60px;
              position: relative;
              background: white !important;
            }
            .asc-table th {
              height: 35px;
              font-weight: bold;
            }
            .slot-num {
              font-size: 12px;
              font-weight: bold;
            }
            .slot-time {
              font-size: 8px;
              font-weight: normal;
            }
            .day-col {
              width: 50px;
              font-size: 20px;
              font-weight: bold;
              text-align: center;
            }
            .cell-initials {
              position: absolute;
              top: 1px;
              left: 1px;
              font-size: 7px;
              font-weight: bold;
            }
            .cell-class {
              font-size: 14px;
              font-weight: bold;
              text-align: center;
              display: flex;
              align-items: center;
              justify-content: center;
              height: 100%;
            }
            .header-text {
              font-size: 28px;
              font-weight: normal;
              text-align: center;
              margin-bottom: 15px;
              font-family: sans-serif;
            }
            .footer {
              display: flex;
              justify-content: space-between;
              font-size: 9px;
              margin-top: 10px;
              font-family: sans-serif;
            }
          }
        `}),t.jsxs("div",{className:"p-4 bg-white",children:[t.jsxs("h1",{className:"header-text",children:["Teacher ",u," ( ",f," )"]}),t.jsxs("table",{className:"asc-table",children:[t.jsx("thead",{children:t.jsxs("tr",{children:[t.jsx("th",{style:{width:"60px"}}),d.map(e=>t.jsxs("th",{children:[t.jsx("div",{className:"slot-num",children:e}),t.jsx("div",{className:"slot-time",children:p[e]})]},e))]})}),t.jsx("tbody",{children:S.filter(e=>e!=="SABTU"||i.some(n=>n.hari==="SABTU")).map(e=>t.jsxs("tr",{children:[t.jsx("td",{className:"day-col",children:w[e]}),d.map(n=>{const a=x(e,n),r=a?.Guru?.User?.full_name?a.Guru.User.full_name.split(" ").map(o=>o[0]).join("").toUpperCase().substring(0,2):"";return t.jsx("td",{children:a&&t.jsxs(t.Fragment,{children:[t.jsx("div",{className:"cell-initials",children:r}),t.jsx("div",{className:"cell-class",children:a.Kelas?.nama_kelas})]})},n)})]},e))})]}),t.jsxs("div",{className:"footer",children:[t.jsxs("div",{children:["Menghasilkan jadwal: ",j(new Date,"dd/MM/yyyy",{locale:y})]}),t.jsx("div",{children:"aSc Timetables"})]})]})]});return g.createPortal(b,document.body)};export{U as JadwalPrintLayout};
