import{a1 as e}from"./index-RCmYd9zv.js";const r=async()=>e("get","/academic/prep-checklist",{headers:{"X-Skip-403-Redirect":"true"}});export{r as g};
