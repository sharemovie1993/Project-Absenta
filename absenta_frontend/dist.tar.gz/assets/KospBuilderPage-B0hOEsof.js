const __vite__mapDeps=(i,m=__vite__mapDeps,d=(m.f||(m.f=["assets/KospWordEditorModal-DlvCVgvM.js","assets/vendor-react-uy527Wia.js","assets/WordEditorModal-W8UuuadO.js","assets/Tabs-R7gyfiIf.js","assets/index-RCmYd9zv.js","assets/vendor-query-CYzCWYOg.js","assets/vendor-ui-libs-CxzdiCX-.js","assets/vendor-axios-B9ygI19o.js","assets/vendor-icons-D4YCjwXr.js","assets/vendor-date-C4CBSu5o.js","assets/vendor-socket-Ba-X_5Ya.js","assets/index-C1hgUR1K.css","assets/vendor-framer-SjYE5Dms.js","assets/Input-BKinjaHP.js","assets/Modal-CubrZjl0.js","assets/navStore-B_6s4o_G.js","assets/CleanDeckCard-JxdmxemP.js","assets/SectionCard-CVyT3adc.js","assets/AnalyticsCard-Bbyyc8NJ.js","assets/Textarea-DOi7F1nZ.js","assets/PrintHeader-BRIn17_j.js","assets/sekolah.api-BqkKwin_.js","assets/UniversalTeacherIdentity-CnOJnCO_.js","assets/strukturOrganisasi.api-DwkfV_4P.js","assets/rapor.api-CKu5Lv_Y.js","assets/coopDocUtils-DUawdKPc.js","assets/academicIdentityNormalizer-XgZxxoPF.js","assets/SendDocumentWaModal-CQErC_GY.js","assets/whatsapp.api-DybmLOT_.js","assets/HubStatusStrip-DxCZnJmB.js"])))=>i.map(i=>d[i]);
import{s as ca,aO as Ia,a as ma,ac as Ta,B as G,j as Ea,C as Z,L as Ma,_ as La}from"./index-RCmYd9zv.js";import{r as o,R as X,j as a}from"./vendor-react-uy527Wia.js";import{B as aa}from"./Badge-HH0OY5D9.js";import{A as wa}from"./AcademicPageLayout-BEkMQzNU.js";import{T as va}from"./TahunPelajaranSelect-x3PGMZ-p.js";import"./RuanganSelect-DFs1USO0.js";import"./SiswaIdentityCell-CIcRWOqO.js";import{n as ea}from"./vendor-ui-libs-CxzdiCX-.js";import"./AcademicFilterToolbar-BZkln4ki.js";import{u as J,a as _a,b as Ra}from"./vendor-query-CYzCWYOg.js";import{u as Ua}from"./useTahunPelajaranOptions-BtF0-o_K.js";import{u as Oa}from"./useJurusanOptions-BfbHA_oR.js";import{s as za}from"./sekolah.api-BqkKwin_.js";import{kurikulumApi as ua}from"./kurikulum.api-CwWeggXz.js";import{a as Ba}from"./strukturOrganisasi.api-DwkfV_4P.js";import{d as Da,b as ba,c as Ha}from"./masterStrukturHelper-BhLUOy4i.js";import{Modal as Ca}from"./Modal-CubrZjl0.js";import{I as z}from"./Input-BKinjaHP.js";import{dY as $a,U as Ja,R as Ga,a3 as Wa,a4 as Fa,F as Va,a7 as Xa,l as qa,b0 as Ya,S as Qa,k as Za,B as ae,h as ee,g as te,V as ne,u as se}from"./vendor-icons-D4YCjwXr.js";import{u as ie}from"./useConfirm-BOJsVoiT.js";import"./vendor-axios-B9ygI19o.js";import"./vendor-date-C4CBSu5o.js";import"./vendor-socket-Ba-X_5Ya.js";import"./AnalyticsCard-Bbyyc8NJ.js";import"./InfraErrorBoundary-B1hq9ty0.js";import"./hardeningRegistry-uruMXjNk.js";import"./SearchableSelect-BaV_k6ya.js";import"./useDebounce-BwUzY3rN.js";import"./useRuanganOptions-Dui4aUe8.js";import"./sarpras.api-Da59Rd1X.js";import"./jspdf.es.min-B8I66jMX.js";import"./jspdf.plugin.autotable-CbV6WxIO.js";import"./JamKBMTypes-CTOha7Cr.js";import"./vendor-zod-BEI-rK-b.js";import"./vendor-framer-SjYE5Dms.js";function re(){const{user:t}=ca(),n=J({queryKey:["my-tenant-jam-kbm",t?.tenant_id],queryFn:()=>t?.tenant_id?Ia(t.tenant_id).catch(()=>null):null,enabled:!!t?.tenant_id,staleTime:600*1e3}),e=n.data?.data||null,d=e?.shift_jam_pelajaran||null,u=d?.shifts||[],p=d?.class_assignments||{};return{...n,tenant:e,shiftJamPelajaran:d,shifts:u,classAssignments:p,hasConfiguredShifts:u.length>0&&(u[0]?.slots?.length??0)>0}}const xa={getConfigByTahun:async t=>(await ma.get(`/kurikulum/kosp-config?tahun_pelajaran_id=${t}`)).data,upsertConfig:async t=>(await ma.put("/kurikulum/kosp-config",t)).data},ka=["Sampul Depan (Cover Resmi)","Kata Pengantar","Daftar Isi Naskah KOSP","Halaman Pengesahan Resmi","Bab I: Karakteristik Satuan Pendidikan","Bab II: Visi, Misi, & Tujuan Sekolah","Bab III: Pengorganisasian Pembelajaran & PKL","Bab IV: Rencana Pembelajaran & Asesmen","Bab V: Pendampingan, Evaluasi, & Pengembangan Profesional","Lampiran 1: SK Tim Penyusun KOSP","Lampiran 2: Struktur Kurikulum Live Semua Jurusan","Lampiran 3: Kalender Pendidikan Sekolah","Lampiran 4: Alokasi Jam KBM Harian","Lampiran 5: Mitra Industri & DUDI PKL"],ha=()=>[{label:ka[0],html:`
        <div style="text-align:center; padding:20px 10px; font-family:Arial, sans-serif;">
          <!-- Top Border Accent -->
          <div style="width:100%; height:6px; background:linear-gradient(to right, #1e3a8a, #3b82f6, #1e3a8a); margin-bottom:24px;"></div>

          <h1 style="margin:0; font-size:20pt; font-weight:bold; color:#0f172a; letter-spacing:1px; text-transform:uppercase;">
            KURIKULUM OPERASIONAL<br/>SATUAN PENDIDIKAN (KOSP)
          </h1>
          <h2 style="margin:8px 0 0 0; font-size:14pt; font-weight:bold; color:#1e40af; text-transform:uppercase;">
            {{NAMASEKOLAH}}
          </h2>
          <p style="margin:6px 0 0 0; font-size:12pt; font-weight:bold; color:#475569;">
            TAHUN AJARAN {{TAHUNPELAJARAN}}
          </p>

          <!-- Dynamic Logo -->
          <div style="margin:36px auto;">
            {{LOGOSEKOLAH_HTML}}
          </div>

          <div style="margin-top:20px; font-size:11pt; color:#334155;">
            <p style="margin:2px 0; font-weight:bold; font-size:12pt; text-transform:uppercase;">DISUSUN OLEH:</p>
            <p style="margin:2px 0; font-weight:bold; color:#1e293b;">TIM PENGEMBANG KURIKULUM</p>
            <p style="margin:2px 0; font-weight:bold; color:#1e40af;">{{NAMASEKOLAH}}</p>
            <p style="margin:6px 0 0 0; font-size:10pt; color:#64748b;">SK Kepala Sekolah Nomor: <strong>{{NOMOR_SK}}</strong></p>
          </div>

          <div style="margin-top:48px; border-top:2px solid #e2e8f0; padding-top:16px; font-size:10.5pt; color:#64748b; line-height:1.6;">
            <strong style="color:#334155;">{{NAMA_DINAS_PROVINSI}}</strong><br/>
            <strong style="color:#334155;">{{NAMA_CABDIN}}</strong><br/>
            <span>Alamat: {{ALAMATSEKOLAH}} &bull; {{KOTASEKOLAH}}</span>
          </div>

          <!-- Bottom Border Accent -->
          <div style="width:100%; height:6px; background:linear-gradient(to right, #1e3a8a, #3b82f6, #1e3a8a); margin-top:24px;"></div>
        </div>
      `},{label:"Kata Pengantar",html:`
        <div style="font-family:Arial, sans-serif;">
          <h3 style="text-align:center; font-size:14pt; font-weight:bold; text-transform:uppercase; margin-top:0;">KATA PENGANTAR</h3>
          
          <p style="text-align:justify; font-size:11pt; line-height:1.6; text-indent:30px;">
            Puji dan syukur kami panjatkan ke hadirat Allah SWT Tuhan Yang Maha Esa, karena atas rahmat dan karunia-Nya naskah Dokumen <strong>Kurikulum Operasional Satuan Pendidikan (KOSP) {{NAMASEKOLAH}} Tahun Ajaran {{TAHUNPELAJARAN}}</strong> ini telah berhasil disusun dan diselesaikan dengan baik.
          </p>
          <p style="text-align:justify; font-size:11pt; line-height:1.6; text-indent:30px;">
            Kurikulum ini disusun berbasis Kurikulum Merdeka (Kepmendikbudristek No. 262/M/2022) serta mengacu pada karakteristik sosial-kultural sekolah, potensi daerah, dan kebutuhan Industri / Dunia Usaha dan Dunia Kerja (DUDI) mitra. KOSP ini menjadi pedoman utama dalam penyelenggaraan intrakurikuler, kokurikuler (P5), serta Praktik Kerja Lapangan (PKL).
          </p>
          <p style="text-align:justify; font-size:11pt; line-height:1.6; text-indent:30px;">
            Ucapan terima kasih dan penghargaan kami sampaikan kepada Tim Penyusun Kurikulum, Komite Sekolah, Pengawas Pembina, serta DUDI Pasangan yang telah memberikan kontribusi pemikiran dan masukan berharga.
          </p>

          <div style="margin-top:30px; text-align:right; font-size:11pt;">
            {{KOTASEKOLAH}}, {{TANGGALPENGESAHAN}}<br/>
            Kepala Sekolah,<br/><br/><br/><br/>
            <strong><u>{{NAMAKEPALASEKOLAH}}</u></strong><br/>
            NIP. {{NIPKEPALASEKOLAH}}
          </div>
        </div>
      `},{label:"Daftar Isi Naskah KOSP",html:`
        <div style="font-family:Arial, sans-serif;">
          <h3 style="text-align:center; font-size:14pt; font-weight:bold; text-transform:uppercase; margin-top:0;">DAFTAR ISI NASKAH KOSP</h3>
          <table style="width:100%; font-size:11pt; border-collapse:collapse; line-height:1.8;">
            <tr><td style="font-weight:bold;">HALAMAN COVER / SAMPUL DEPAN</td><td style="text-align:right;">i</td></tr>
            <tr><td style="font-weight:bold;">LEMBAR PENGESAHAN KURIKULUM</td><td style="text-align:right;">ii</td></tr>
            <tr><td style="font-weight:bold;">KATA PENGANTAR & DAFTAR ISI</td><td style="text-align:right;">iii</td></tr>
            <tr><td style="font-weight:bold;">BAB I: KARAKTERISTIK SATUAN PENDIDIKAN</td><td style="text-align:right;">1</td></tr>
            <tr><td style="font-weight:bold;">BAB II: VISI, MISI, DAN TUJUAN SEKOLAH</td><td style="text-align:right;">3</td></tr>
            <tr><td style="font-weight:bold;">BAB III: PENGORGANISASIAN PEMBELAJARAN & PKL</td><td style="text-align:right;">5</td></tr>
            <tr><td style="font-weight:bold;">BAB IV: RENCANA PEMBELAJARAN DAN ASESMEN</td><td style="text-align:right;">8</td></tr>
            <tr><td style="font-weight:bold;">BAB V: PENDAMPINGAN, EVALUASI, & PENGEMBANGAN PROFESIONAL</td><td style="text-align:right;">10</td></tr>
            <tr><td style="font-weight:bold;">LAMPIRAN 1: SK TIM PENYUSUN KOSP</td><td style="text-align:right;">12</td></tr>
            <tr><td style="font-weight:bold;">LAMPIRAN 2: TABEL STRUKTUR KURIKULUM LIVE SEMUA JURUSAN</td><td style="text-align:right;">14</td></tr>
            <tr><td style="font-weight:bold;">LAMPIRAN 3: KALENDER PENDIDIKAN & HARI EFEKTIF</td><td style="text-align:right;">17</td></tr>
            <tr><td style="font-weight:bold;">LAMPIRAN 4: PENGATURAN JAM KBM & ROSTER</td><td style="text-align:right;">19</td></tr>
            <tr><td style="font-weight:bold;">LAMPIRAN 5: DAFTAR INDUSTRI PASANGAN (DUDI MITRA PKL)</td><td style="text-align:right;">21</td></tr>
          </table>
        </div>
      `},{label:"Halaman Pengesahan Resmi",html:`
        <div style="text-align:center; margin-bottom:20px;">
          <h2 style="margin:0; font-size:16pt; font-weight:bold; text-transform:uppercase;">LEMBAR PENGESAHAN</h2>
          <h3 style="margin:6px 0 0 0; font-size:13pt; font-weight:bold; text-transform:uppercase;">KURIKULUM OPERASIONAL SATUAN PENDIDIKAN (KOSP)</h3>
          <h4 style="margin:4px 0 0 0; font-size:12pt; font-weight:bold; color:#2563eb;">{{NAMASEKOLAH}}</h4>
          <p style="margin:4px 0 0 0; font-size:11pt; font-weight:bold;">TAHUN AJARAN {{TAHUNPELAJARAN}}</p>
        </div>

        <p style="text-align:justify; font-size:11pt; line-height:1.6; text-indent:30px;">
          Setelah memperhatikan pertimbangan dan masukan dari Komite Sekolah, Industri/DUDI Pasangan, serta Dinas Pendidikan Provinsi, dengan ini Kurikulum Operasional Satuan Pendidikan (KOSP) <strong>{{NAMASEKOLAH}}</strong> Tahun Ajaran <strong>{{TAHUNPELAJARAN}}</strong> ditetapkan dan disahkan untuk diberlakukan.
        </p>

        <div style="margin-top:40px;">
          <table style="width:100%; font-size:11pt; border-collapse:collapse;">
            <tr>
              <td style="width:50%; text-align:left; vertical-align:top;">
                Ditetapkan di: {{KOTASEKOLAH}}<br/>
                Pada Tanggal: {{TANGGALPENGESAHAN}}
              </td>
              <td style="width:50%; text-align:left; vertical-align:top;">
                Menyetujui,<br/>
                <strong>Ketua Komite Sekolah</strong>
                <br/><br/><br/><br/>
                <strong><u>{{NAMAKETUAKOMITE}}</u></strong>
              </td>
            </tr>
            <tr>
              <td style="padding-top:30px; text-align:left; vertical-align:top;">
                Mengetahui,<br/>
                <strong>Kepala Sekolah</strong>
                <br/><br/><br/><br/>
                <strong><u>{{NAMAKEPALASEKOLAH}}</u></strong><br/>
                NIP. {{NIPKEPALASEKOLAH}}
              </td>
              <td style="padding-top:30px; text-align:left; vertical-align:top;">
                Mengesahkan,<br/>
                <strong>An. Kepala Dinas Pendidikan Provinsi</strong><br/>
                Kepala Cabang Dinas Pendidikan
                <br/><br/><br/><br/>
                <strong><u>{{NAMAKEPAKACABDIN}}</u></strong><br/>
                NIP. {{NIPKEPAKACABDIN}}
              </td>
            </tr>
          </table>
        </div>
      `},{label:"Bab I: Karakteristik Satuan Pendidikan",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">BAB I: KARAKTERISTIK SATUAN PENDIDIKAN</h3>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:14px; color:#1e293b;">A. Gambaran Umum & Context Sekolah</h4>
        <div class="kosp-section-karakteristik">
          {{KARAKTERISTIK_SEKOLAH}}
        </div>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:16px; color:#1e293b;">B. Karakteristik Konsentrasi Keahlian (Jurusan-Jurusan)</h4>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          {{NAMASEKOLAH}} menyelenggarakan program pendidikan keahlian berbasis Kurikulum Merdeka yang disesuaikan dengan kebutuhan Industri, Dunia Usaha, dan Dunia Kerja (DUDI) mitra, meliputi:
        </p>
        {{DAFTAR_JURUSAN_SUMMARY}}
      `},{label:"Bab II: Visi, Misi, & Tujuan Sekolah",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">BAB II: VISI, MISI, DAN TUJUAN</h3>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:14px; color:#1e293b;">A. Visi Sekolah</h4>
        <div style="background-color:#f8fafc; border-left:4px solid #2563eb; padding:10px 14px; font-size:11pt; font-style:italic;">
          {{VISI_SEKOLAH}}
        </div>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:16px; color:#1e293b;">B. Misi Sekolah</h4>
        <div class="kosp-section-misi" style="font-size:11pt; line-height:1.6;">
          {{MISI_SEKOLAH}}
        </div>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:16px; color:#1e293b;">C. Tujuan Satuan Pendidikan</h4>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          Mewujudkan lulusan SMK yang beriman, bertaqwa, berkebhinekaan global, mandiri, kreatif, bernalar kritis, dan bergotong royong serta memiliki kompetensi keahlian yang diakui oleh dunia industri.
        </p>
      `},{label:"Bab III: Pengorganisasian Pembelajaran & PKL",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">BAB III: PENGORGANISASIAN PEMBELAJARAN</h3>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:14px; color:#1e293b;">A. Intrakurikuler (Struktur Kurikulum Live)</h4>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          Struktur kurikulum intrakurikuler pada {{NAMASEKOLAH}} disusun berdasarkan Kepmendikbudristek No. 262/M/2022 tentang Perubahan atas Kepmendikbudristek No. 56/M/2022 tentang Pedoman Penerapan Kurikulum dalam Rangka Pemulihan Pembelajaran.
        </p>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:18px; color:#1e293b;">B. Projek Penguatan Profil Pelajar Pancasila (P5) & Budaya Kerja</h4>
        {{TABEL_P5_MATRIKS}}

        <h4 style="font-size:12pt; font-weight:bold; margin-top:18px; color:#1e293b;">C. Skema Praktik Kerja Lapangan (PKL)</h4>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          PKL dilaksanakan selama 1 (satu) semester penuh di Kelas XII (Semester Ganjil) dengan bobot 44-46 JP/minggu di Dunia Usaha/Dunia Kerja (DUDI) mitra. Pada semester ini, mata pelajaran Konsentrasi Keahlian (KK) dan Projek Kreatif (PKK) digantikan secara utuh oleh kegiatan PKL di Industri.
        </p>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:18px; color:#1e293b;">D. Ekstrakurikuler & Pengembangan Diri</h4>
        {{TABEL_ESKUL_MATRIKS}}
      `},{label:"Bab IV: Rencana Pembelajaran & Asesmen",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">BAB IV: RENCANA PEMBELAJARAN DAN ASESMEN</h3>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:14px; color:#1e293b;">A. Prinsip Pembelajaran Berbasis Kurikulum Merdeka</h4>
        <p style="text-align:justify; font-size:11pt; line-height:1.6;">
          Pembelajaran di {{NAMASEKOLAH}} dirancang berdasarkan prinsip <strong>student-centered learning</strong>, berpusat pada kebutuhan, potensi, dan perkembangan peserta didik. Pendekatan yang digunakan mengintegrasikan pengetahuan, keterampilan, dan sikap secara holistik melalui:<br/>
          (1) Alur Tujuan Pembelajaran (ATP) sebagai panduan urutan belajar, (2) Modul Ajar berbasis konteks industri lokal, (3) Pembelajaran Berbasis Proyek (PBL), dan (4) Asesmen Autentik berbasis kinerja.
        </p>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:16px; color:#1e293b;">B. Sistem Penilaian & Asesmen</h4>
        <p style="text-align:justify; font-size:11pt; line-height:1.6;">
          Penilaian dilaksanakan secara berkesinambungan dan menyeluruh:
        </p>
        <ul style="font-size:11pt; line-height:1.8; padding-left:20px;">
          <li><strong>Asesmen Formatif:</strong> Penilaian harian, observasi, diskusi kelas, dan refleksi diri.</li>
          <li><strong>Asesmen Sumatif Tengah Semester (ASTS):</strong> Penilaian tertulis/praktik di tengah semester.</li>
          <li><strong>Asesmen Sumatif Akhir Semester (ASAS):</strong> Penilaian komprehensif akhir semester.</li>
          <li><strong>Uji Kompetensi Keahlian (UKK):</strong> Penilaian praktik keahlian bersertifikat Kelas XII bersama DUDI/LSP.</li>
          <li><strong>Portofolio Projek:</strong> Dokumentasi karya dan hasil P5/PKL peserta didik.</li>
        </ul>
      `},{label:"Bab V: Pendampingan, Evaluasi, & Pengembangan Profesional",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">BAB V: PENDAMPINGAN, EVALUASI, & PENGEMBANGAN PROFESIONAL</h3>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:14px; color:#1e293b;">A. Evaluasi KOSP</h4>
        <p style="text-align:justify; font-size:11pt; line-height:1.6;">
          Evaluasi KOSP dilakukan secara berkala setiap akhir semester dan akhir tahun pelajaran oleh <strong>Tim Penjaminan Mutu Internal Sekolah (TPMIS)</strong> bersama Kepala Sekolah, Pengawas Pembina, dan representasi Komite Sekolah. Evaluasi mencakup ketercapaian target kurikulum, efektivitas pembelajaran, dan relevansi dengan kebutuhan DUDI.
        </p>

        <h4 style="font-size:12pt; font-weight:bold; margin-top:16px; color:#1e293b;">B. Pendampingan Profesional Guru</h4>
        <ul style="font-size:11pt; line-height:1.8; padding-left:20px;">
          <li><strong>Supervisi Akademik:</strong> Dilaksanakan oleh Kepala Sekolah dan Pengawas Pembina minimal 2x per semester.</li>
          <li><strong>In-House Training (IHT):</strong> Pelatihan internal peningkatan kompetensi pedagogis dan vokasional guru.</li>
          <li><strong>Magang Industri Guru (Teacher Industrial Attachment):</strong> Program magang guru di DUDI mitra 1-2 minggu per tahun.</li>
          <li><strong>Komunitas Belajar (KomBel):</strong> Forum berbagi praktik baik antar guru mapel sejenis setiap bulan.</li>
        </ul>
      `},{label:"Lampiran 1: SK Tim Penyusun KOSP",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">LAMPIRAN 1: SK TIM PENYUSUN KOSP</h3>

        <div style="background:#f8fafc; border:1px solid #e2e8f0; border-left:4px solid #1e40af; padding:10px 14px; font-size:11pt; margin-bottom:16px; border-radius:4px;">
          <strong>Nomor SK:</strong> {{NOMOR_SK}}<br/>
          <strong>Tanggal Penetapan:</strong> {{TANGGALPENGESAHAN}}
        </div>

        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          Berdasarkan SK Kepala Sekolah Nomor: <strong>{{NOMOR_SK}}</strong>, susunan Tim Pengembang &amp; Penyusun Kurikulum Operasional Satuan Pendidikan (KOSP) <strong>{{NAMASEKOLAH}}</strong> Tahun Ajaran <strong>{{TAHUNPELAJARAN}}</strong> adalah sebagai berikut:
        </p>

        {{TABEL_SK_TIM_PENYUSUN}}
      `},{label:"Lampiran 2: Struktur Kurikulum Live Semua Jurusan",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">LAMPIRAN 2: TABEL STRUKTUR KURIKULUM RESMI</h3>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          Tabel Alokasi Jam Pelajaran (JP) per minggu/semester untuk setiap konsentrasi keahlian pada {{NAMASEKOLAH}} Tahun Ajaran {{TAHUNPELAJARAN}}:
        </p>

        {{TABEL_STRUKTUR_KURIKULUM_SEMUA_JURUSAN}}
      `},{label:"Lampiran 3: Kalender Pendidikan Sekolah",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">LAMPIRAN 3: KALENDER PENDIDIKAN SEKOLAH</h3>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          Kalender Pendidikan {{NAMASEKOLAH}} Tahun Ajaran {{TAHUNPELAJARAN}} beserta rincian minggu efektif dan agenda kegiatan akademik:
        </p>

        {{TABEL_KALENDER_PENDIDIKAN}}
      `},{label:"Lampiran 4: Pengaturan Jam KBM & Roster",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">LAMPIRAN 4: ALOKASI WAKTU JAM KBM</h3>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          Struktur rentang waktu Kegiatan Belajar Mengajar (KBM) harian {{NAMASEKOLAH}}:
        </p>

        {{TABEL_JAM_KBM}}
      `},{label:"Lampiran 5: Mitra Industri / DUDI Pasangan",html:`
        <h3 style="font-size:14pt; font-weight:bold; border-bottom:2px solid #0f172a; padding-bottom:4px; margin-top:0;">LAMPIRAN 5: DAFTAR INDUSTRI PASANGAN (DUDI MITRA)</h3>
        <p style="text-align:justify; font-size:11pt; line-height:1.5;">
          Daftar Dunia Usaha, Dunia Industri, dan Dunia Kerja (DUDI) mitra kerja sama {{NAMASEKOLAH}} dalam pelaksanaan Praktik Kerja Lapangan (PKL), sinkronisasi kurikulum, dan rekrutmen lulusan:
        </p>

        {{TABEL_DUDI_MITRA}}
      `}],oe=(t,n="Sekolah")=>t?`<img src="${t}" alt="Logo Sekolah" style="max-height:160px; width:auto; margin:24px auto; display:block; object-fit:contain;" />`:`
    <div style="width:140px; height:140px; margin:28px auto; border-radius:50%; background-color:#eff6ff; border:3px double #2563eb; display:flex; align-items:center; justify-content:center; text-align:center; color:#1e40af; font-weight:bold; font-size:12px; padding:12px; box-sizing:border-box;">
      LOGO RESMI<br/>${n.toUpperCase()}
    </div>
  `,ta=t=>{if(!t||!t.trim())return!0;const n=t.trim().toLowerCase();return n==="kepala sekolah"||n==="wakasek kurikulum"||n==="wakasek bidang kurikulum"||n==="wakasek bidang kesiswaan"||n==="wakasek kesiswaan"||n==="wakasek bidang humas & hubin"||n==="wakasek humas/dudi"||n==="wakasek bidang sarana prasarana"||n==="wakasek sarpras"||n==="para ketua program keahlian (kaprog)"||n==="kaprog keahlian"||n==="koor. bimbingan konseling (bk)"||n==="guru bk"||n==="koordinator tata usaha"||n==="kepala tata usaha"},I=(t,n,e)=>{if(!t)return e;const d=[n,n.toUpperCase(),n.toLowerCase(),n==="TU_KEPALA"?"TU":null,n==="TU"?"TU_KEPALA":null].filter(Boolean);for(const u of d){const p=t[u];if(p&&Array.isArray(p)){for(const N of p)if(N.members&&Array.isArray(N.members))for(const l of N.members){const x=l?.name||l?.nama||l?.User?.Guru?.nama_guru;if(x&&typeof x=="string"&&x!=="Unknown"&&x.trim())return x.trim()}}}return e},le=(t,n,e,d)=>{const u=[{no:1,nama:I(d,"KEPALA_SEKOLAH",t),jabatan_kedinasan:"Kepala Sekolah",jabatan_tim:"Penanggung Jawab"},{no:2,nama:I(d,"KURIKULUM",n),jabatan_kedinasan:"Wakasek Bidang Kurikulum",jabatan_tim:"Ketua Tim Penyusun"},{no:3,nama:"Drs. H. Mulyana, M.Pd.",jabatan_kedinasan:"Pengawas Pembina Sekolah",jabatan_tim:"Narasumber / Pendamping"},{no:4,nama:"H. Dudung Abdurrahman, M.Pd.",jabatan_kedinasan:"Ketua Komite Sekolah",jabatan_tim:"Narasumber Komite"},{no:5,nama:I(d,"KESISWAAN","Wakasek Bidang Kesiswaan"),jabatan_kedinasan:"Wakasek Kesiswaan",jabatan_tim:"Anggota / Tim Pengembang"},{no:6,nama:I(d,"HUBIN","Wakasek Bidang Humas & Hubin"),jabatan_kedinasan:"Wakasek Humas/DUDI",jabatan_tim:"Anggota / Tim Penyelaras DUDI"},{no:7,nama:I(d,"SARPRAS","Wakasek Bidang Sarana Prasarana"),jabatan_kedinasan:"Wakasek Sarpras",jabatan_tim:"Anggota / Tim Fasilitas"},{no:8,nama:I(d,"KAPROG","Para Ketua Program Keahlian (Kaprog)"),jabatan_kedinasan:"Kaprog Keahlian",jabatan_tim:"Anggota / Tim Kurikulum Jurusan"},{no:9,nama:I(d,"BPBK","Koor. Bimbingan Konseling (BK)"),jabatan_kedinasan:"Guru BK",jabatan_tim:"Anggota / Tim Asesmen & Karakter"},{no:10,nama:I(d,"TU_KEPALA","Koordinator Tata Usaha"),jabatan_kedinasan:"Kepala Tata Usaha",jabatan_tim:"Anggota / Tim Administrasi"}];let p=e&&e.length>0?e:u;if(d&&Object.keys(d).length>0){const l={1:"KEPALA_SEKOLAH",2:"KURIKULUM",5:"KESISWAAN",6:"HUBIN",7:"SARPRAS",8:"KAPROG",9:"BPBK",10:"TU_KEPALA"};p=p.map(x=>{const k=l[x.no||0];if(k&&ta(x.nama)){const K=I(d,k,x.nama);if(K&&K!==x.nama)return{...x,nama:K}}return x})}return`
    <div style="margin-top:12px; margin-bottom:20px;">
      <h4 style="margin:0 0 6px 0; font-size:12px; font-weight:bold; color:#0f172a; text-transform:uppercase;">
        Susunan Tim Pengembang & Penyusun KOSP
      </h4>
      <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
        <thead>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:7%;">NO</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:33%;">NAMA PERSONAL</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:30%;">JABATAN KEDINASAN</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:30%;">TUGAS DALAM TIM</th>
          </tr>
        </thead>
        <tbody>
          ${p.map((l,x)=>`
    <tr>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${l.no||x+1}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; font-weight:bold;">${l.nama}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${l.jabatan_kedinasan}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center; font-weight:bold; color:#1e3a8a;">${l.jabatan_tim}</td>
    </tr>
  `).join("")}
        </tbody>
      </table>
    </div>
  `},de=()=>`
    <div style="margin-top:12px; margin-bottom:20px;">
      <h4 style="margin:0 0 6px 0; font-size:12px; font-weight:bold; color:#0f172a; text-transform:uppercase;">
        Matriks Tema Projek Penguatan Profil Pelajar Pancasila (P5) & Budaya Kerja
      </h4>
      <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
        <thead>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:7%;">NO</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:33%;">TEMA P5</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:22%;">SASARAN & WAKTU</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:38%;">FOCUS CAPAIAN PROJECT</th>
          </tr>
        </thead>
        <tbody>
          ${[{no:1,tema:"Gaya Hidup Berkelanjutan",alokasi:"Kelas X (Sem 1)",target:"Kesadaran Pengelolaan Sampah & Lingkungan Sekolah"},{no:2,tema:"Kearifan Lokal",alokasi:"Kelas X (Sem 2)",target:"Pelestarian Seni Budaya & Tradisi Daerah"},{no:3,tema:"Bhinneka Tunggal Ika",alokasi:"Kelas XI (Sem 1)",target:"Toleransi & Moderasi Beragama dalam Kebinekaan"},{no:4,tema:"Kebekerjaan (Tema Wajib SMK)",alokasi:"Kelas XI (Sem 2) & XII",target:"Budaya Kerja Industri (5R/5S), K3LH, & Soft Skills"}].map(e=>`
    <tr>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${e.no}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; font-weight:bold; color:#0f172a;">${e.tema}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${e.alokasi}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${e.target}</td>
    </tr>
  `).join("")}
        </tbody>
      </table>
    </div>
  `,pe=()=>`
    <div style="margin-top:12px; margin-bottom:20px;">
      <h4 style="margin:0 0 6px 0; font-size:12px; font-weight:bold; color:#0f172a; text-transform:uppercase;">
        Program Pengembangan Diri & Ekstrakurikuler Sekolah
      </h4>
      <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
        <thead>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:6%;">NO</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:15%;">SIFAT</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:30%;">NAMA EKSTRAKURIKULER</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:24%;">TARGET PESERTA</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:25%;">PEMBINA / PELATIH</th>
          </tr>
        </thead>
        <tbody>
          ${[{no:1,jenis:"Wajib",nama:"Pramuka (Kepramukaan)",sasaran:"Seluruh Siswa Kelas X",pembina:"Tim Pembina Kepramukaan"},{no:2,jenis:"Pilihan (Bela Negara)",nama:"Paskibra & PMR",sasaran:"Siswa Minat Kelas X & XI",pembina:"Pembina Paskibra & PMR"},{no:3,jenis:"Pilihan (Olahraga)",nama:"Futsal, Bola Voli, Basket, Pencak Silat",sasaran:"Siswa Minat Kelas X, XI, XII",pembina:"Guru Olahraga & Pelatih Eksternal"},{no:4,jenis:"Pilihan (Seni & Komputer)",nama:"Seni Musik, Marawis, IT Club & Design",sasaran:"Siswa Minat Kelas X & XI",pembina:"Pembina Seni & Komputer"},{no:5,jenis:"Pilihan (Kerohanian)",nama:"ROHIS / Ikatan Remaja Masjid",sasaran:"Seluruh Siswa Muslim",pembina:"Guru Agama Islam"}].map(e=>`
    <tr>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${e.no}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center; font-weight:bold; color:${e.jenis==="Wajib"?"#b91c1c":"#0369a1"};">${e.jenis}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; font-weight:bold;">${e.nama}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${e.sasaran}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${e.pembina}</td>
    </tr>
  `).join("")}
        </tbody>
      </table>
    </div>
  `,ge=(t=[])=>!t||t.length===0?`
      <div style="padding:10px; border:1px solid #cbd5e1; border-radius:6px; background:#f8fafc; font-size:11px; text-align:center; color:#64748b;">
        <em>Kalender Pendidikan disesuaikan dengan Keputusan Kepala Dinas Pendidikan Provinsi setempat tentang Kalender Pendidikan Tahun Ajaran berjalan.</em>
      </div>
    `:`
    <div style="margin-top:12px; margin-bottom:20px;">
      <h4 style="margin:0 0 6px 0; font-size:12px; font-weight:bold; color:#0f172a; text-transform:uppercase;">
        Agenda Kegiatan Kalender Pendidikan Sekolah
      </h4>
      <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
        <thead>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:7%;">NO</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:28%;">TANGGAL / WAKTU</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:45%;">NAMA KEGIATAN</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:20%;">KATEGORI</th>
          </tr>
        </thead>
        <tbody>
          ${t.map((e,d)=>`
    <tr>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${d+1}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${e.tanggal||e.tgl||"-"}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; font-weight:bold;">${e.kegiatan||e.nama_kegiatan||"-"}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${e.keterangan||e.kat||"Kegiatan Akademik"}</td>
    </tr>
  `).join("")}
        </tbody>
      </table>
    </div>
  `,me=t=>{if(t&&typeof t=="object"&&Array.isArray(t.shifts)&&t.shifts.length>0){const n=[];for(const e of t.shifts){const d=e.name||"Shift Belajar",u=e.slots||[],p=e.slot_duration?`${e.slot_duration} Menit`:"45 Menit";if(!Array.isArray(u)||u.length===0)continue;const N=[];u.forEach(l=>{const x=l.slot||l.jamKe||"-",k=l.start||l.jam_masuk||"",K=l.end||l.jam_keluar||"",T=k&&K?`${k} - ${K}`:l.waktu||"-",m=x===1?"KBM / Pembiasaan / Upacara":"Kegiatan Belajar Mengajar (KBM)";N.push(`
          <tr>
            <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${x}</td>
            <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${T}</td>
            <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${p}</td>
            <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${m}</td>
          </tr>
        `)}),n.push(`
        <div style="margin-top:12px; margin-bottom:16px;">
          <h4 style="margin:0 0 6px 0; font-size:12px; font-weight:bold; color:#0f172a; text-transform:uppercase;">
            Alokasi Waktu Belajar: ${d}
          </h4>
          <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
            <thead>
              <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
                <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:12%;">JAM KE</th>
                <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:28%;">RENTANG WAKTU</th>
                <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:20%;">DURASI</th>
                <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:40%;">URAIAN KEGIATAN</th>
              </tr>
            </thead>
            <tbody>
              ${N.join("")}
            </tbody>
          </table>
        </div>
      `)}if(n.length>0)return n.join("")}return Array.isArray(t)&&t.length>0?`
      <div style="margin-top:12px; margin-bottom:20px;">
        <h4 style="margin:0 0 6px 0; font-size:12px; font-weight:bold; color:#0f172a; text-transform:uppercase;">
          Struktur Alokasi Waktu Belajar Harian (Jam KBM)
        </h4>
        <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
          <thead>
            <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
              <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:12%;">JAM KE</th>
              <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:28%;">RENTANG WAKTU</th>
              <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:20%;">DURASI</th>
              <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:40%;">URAIAN KEGIATAN</th>
            </tr>
          </thead>
          <tbody>
            ${t.map(e=>`
      <tr style="${e.jamKe==="-"?"background-color:#f1f5f9; font-weight:bold;":""}">
        <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${e.jamKe||e.jam_ke||"-"}</td>
        <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${e.waktu||`${e.jam_masuk} - ${e.jam_keluar}`}</td>
        <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${e.durasi||"45 Menit"}</td>
        <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${e.ket||e.keterangan||"KBM"}</td>
      </tr>
    `).join("")}
          </tbody>
        </table>
      </div>
    `:`
    <div style="padding:12px; border:1px dashed #cbd5e1; border-radius:6px; background:#f8fafc; font-size:11px; text-align:center; color:#dc2626; margin-bottom:16px;">
      <em><span style="font-weight:bold;">[⚠️ BELUM DITETAPKAN]</span> Alokasi Jam KBM belum dikonfigurasi pada Modul Pengaturan Jam KBM. Silakan kelola rincian shift & slot jam pelajaran pada menu Pengaturan Jam KBM.</em>
    </div>
  `},ue=(t=[])=>{if(!t||t.length===0)return`
      <div style="padding:10px; border:1px solid #cbd5e1; border-radius:6px; background:#f8fafc; font-size:11px; text-align:center; color:#64748b;">
        <em>Mitra Dunia Usaha / Dunia Kerja (DUDI) bekerja sama secara aktif dalam sinkronisasi kurikulum, pengujian kompetensi, dan pelaksanaan Praktik Kerja Lapangan (PKL).</em>
      </div>
    `;const n=t.slice(0,15),e=t.length>15;return`
    <div style="margin-top:12px; margin-bottom:20px;">
      <h4 style="margin:0 0 6px 0; font-size:12px; font-weight:bold; color:#0f172a; text-transform:uppercase;">
        Daftar Industri Pasangan / DUDI Mitra Pembelajaran
      </h4>
      <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
        <thead>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:7%;">NO</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:33%;">NAMA INDUSTRI / PERUSAHAAN</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:22%;">BIDANG USAHA</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:23%;">ALAMAT / KOTA</th>
            <th style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:15%;">STATUS KERJA SAMA</th>
          </tr>
        </thead>
        <tbody>
          ${n.map((u,p)=>`
    <tr>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center;">${p+1}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; font-weight:bold;">${u.nama||u.nama_mitra||u.nama_perusahaan||"-"}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${u.bidang_usaha||u.bidang||"Industri / Jasa"}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${u.alamat||u.kota||"-"}</td>
      <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px; text-align:center; color:#166534; font-weight:bold;">AKTIF (MoU)</td>
    </tr>
  `).join("")}
        </tbody>
      </table>
      ${e?`<p style="font-size:10px; color:#64748b; margin-top:6px; font-style:italic;">* Menampilkan 15 dari ${t.length} total mitra DUDI. Data lengkap tersedia di modul Hubin.</p>`:""}
    </div>
  `},be=(t,n)=>{const e=t.id,d=t.nama||t.nama_jurusan||"Konsentrasi Keahlian",u=t.singkatan||t.kode||"KONSENTRASI",p=n.filter(i=>!i.jurusan_id||i.jurusan_id===e);if(p.length===0)return`
      <div style="padding:12px; border:1px dashed #cbd5e1; border-radius:6px; background:#f8fafc; text-align:center; color:#64748b; font-size:11px; margin-bottom:16px;">
        <em>Belum ada pemetaan Struktur Kurikulum untuk <strong>${d}</strong> (${u}).</em>
      </div>
    `;const N=new Map;p.forEach(i=>{const r=i.mapel_id,A=i.Mapel?.nama_mapel||i.nama_mapel||"",g=i.Mapel?.kode_mapel||i.kode_mapel||"",f=i.tingkat,y=i.jp_per_minggu;N.has(r)||N.set(r,{id:r,nama:A,kode:g,kelompok:i.kelompok||Da(g,A),jp:{},rawItem:i}),N.get(r).jp[f]=y});const l=Array.from(N.values()).sort((i,r)=>{const A=ba(i.rawItem),g=ba(r.rawItem);return A!==g?A-g:i.nama.localeCompare(r.nama)}),x=l.filter(i=>i.kelompok==="MATA PELAJARAN UMUM"),k=l.filter(i=>i.kelompok==="MATA PELAJARAN KEJURUAN"),K=l.filter(i=>i.kelompok==="MATA PELAJARAN PILIHAN"||i.kelompok==="MUATAN LOKAL"),T=(i,r,A)=>{const g=i.jp[r]||0;return g===0?"-":Ha(i.nama,i.kode,r,A,g)},m=(i,r,A)=>{let g=0;return i.forEach(f=>{const y=T(f,r,A);y!=="-"&&(g+=Number(y))}),g},v=i=>i.map((r,A)=>{const g=T(r,10,1),f=T(r,10,2),y=T(r,11,1),j=T(r,11,2),M=T(r,12,1),L=T(r,12,2);return`
        <tr>
          <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${A+1}. ${r.nama}</td>
          <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${g}</td>
          <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${f}</td>
          <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${y}</td>
          <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${j}</td>
          <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${M}</td>
          <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${L}</td>
        </tr>
      `}).join(""),R=(i,r)=>`
      <tr style="background-color:#f1f5f9; font-weight:bold;">
        <td style="border:1px solid #94a3b8; padding:5px 8px; font-size:10.5px;">${i}</td>
        <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${m(r,10,1)||"-"}</td>
        <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${m(r,10,2)||"-"}</td>
        <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${m(r,11,1)||"-"}</td>
        <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${m(r,11,2)||"-"}</td>
        <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${m(r,12,1)||"-"}</td>
        <td style="border:1px solid #94a3b8; padding:5px; text-align:center; font-size:10.5px;">${m(r,12,2)||"-"}</td>
      </tr>
    `,B=m(l,10,1),U=m(l,10,2),O=m(l,11,1),C=m(l,11,2),_=m(l,12,1),D=m(l,12,2);return`
    <div class="kosp-jurusan-table-block" style="margin-top:8px; margin-bottom:20px; page-break-inside:avoid;">
      <h4 style="margin:0 0 10px 0; font-size:11.5pt; font-weight:bold; color:#0f172a; text-transform:uppercase; border-bottom:2px solid #1e40af; padding-bottom:4px;">
        Struktur Kurikulum Konsentrasi Keahlian: ${d} (${u})
      </h4>
      <table style="width:100%; border-collapse:collapse; font-family:Arial, sans-serif;">
        <thead>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th rowspan="3" style="border:1px solid #94a3b8; padding:6px; font-size:11px; width:45%;">MATA PELAJARAN</th>
            <th colspan="6" style="border:1px solid #94a3b8; padding:4px; font-size:11px;">ALOKASI WAKTU (JP / MINGGU)</th>
          </tr>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th colspan="2" style="border:1px solid #94a3b8; padding:4px; font-size:10.5px;">KELAS X</th>
            <th colspan="2" style="border:1px solid #94a3b8; padding:4px; font-size:10.5px;">KELAS XI</th>
            <th colspan="2" style="border:1px solid #94a3b8; padding:4px; font-size:10.5px;">KELAS XII</th>
          </tr>
          <tr style="background-color:#e2e8f0; font-weight:bold; text-align:center;">
            <th style="border:1px solid #94a3b8; padding:4px; font-size:10px; width:9%;">Sem 1</th>
            <th style="border:1px solid #94a3b8; padding:4px; font-size:10px; width:9%;">Sem 2</th>
            <th style="border:1px solid #94a3b8; padding:4px; font-size:10px; width:9%;">Sem 1</th>
            <th style="border:1px solid #94a3b8; padding:4px; font-size:10px; width:9%;">Sem 2</th>
            <th style="border:1px solid #94a3b8; padding:4px; font-size:10px; width:9%;">Sem 1</th>
            <th style="border:1px solid #94a3b8; padding:4px; font-size:10px; width:9%;">Sem 2</th>
          </tr>
        </thead>
        <tbody>
          <!-- Kelompok A -->
          <tr style="background-color:#f8fafc; font-weight:bold;">
            <td colspan="7" style="border:1px solid #94a3b8; padding:5px 8px; font-size:11px; color:#1e293b;">A. MATA PELAJARAN UMUM</td>
          </tr>
          ${v(x)}
          ${R("Jumlah Jam Kelompok A",x)}

          <!-- Kelompok B -->
          <tr style="background-color:#f8fafc; font-weight:bold;">
            <td colspan="7" style="border:1px solid #94a3b8; padding:5px 8px; font-size:11px; color:#1e293b;">B. MATA PELAJARAN KEJURUAN</td>
          </tr>
          ${v(k)}

          <!-- Kelompok C -->
          ${K.length>0?`
            <tr style="background-color:#f8fafc; font-weight:bold;">
              <td colspan="7" style="border:1px solid #94a3b8; padding:5px 8px; font-size:11px; color:#1e293b;">C. MATA PELAJARAN PILIHAN & MUATAN LOKAL</td>
            </tr>
            ${v(K)}
          `:""}
          ${R("Jumlah Jam Kelompok B + C",[...k,...K])}

          <!-- Total Beban Belajar -->
          <tr style="background-color:#dcfce7; color:#14532d; font-weight:bold;">
            <td style="border:1px solid #86efac; padding:6px 8px; font-size:11px;">TOTAL BEBAN BELAJAR (A + B + C)</td>
            <td style="border:1px solid #86efac; padding:6px; text-align:center; font-size:11px;">${B}</td>
            <td style="border:1px solid #86efac; padding:6px; text-align:center; font-size:11px;">${U}</td>
            <td style="border:1px solid #86efac; padding:6px; text-align:center; font-size:11px;">${O}</td>
            <td style="border:1px solid #86efac; padding:6px; text-align:center; font-size:11px;">${C}</td>
            <td style="border:1px solid #86efac; padding:6px; text-align:center; font-size:11px;">${_}</td>
            <td style="border:1px solid #86efac; padding:6px; text-align:center; font-size:11px;">${D}</td>
          </tr>
        </tbody>
      </table>
    </div>
  `},xe=()=>{const t=_a();ca();const{shiftJamPelajaran:n}=re(),[e,d]=o.useState(""),[u,p]=o.useState(!1),[N,l]=o.useState(!1),{options:x,rawList:k,activeYear:K,isLoading:T}=Ua(),{rawList:m,isLoading:v}=Oa();o.useEffect(()=>{K&&!e?d(K.id):k.length>0&&!e&&d(k[0].id)},[K?.id,k.length]);const{data:R,isLoading:B}=J({queryKey:["hubin-dudi-options-kosp-list"],queryFn:async()=>{try{const b=await Ta.getMitra({limit:200});return Array.isArray(b.data)?b.data:b.data?.list||b.data?.data||(Array.isArray(b)?b:[])}catch{return[]}},staleTime:300*1e3}),{data:U}=J({queryKey:["sekolah-profile"],queryFn:()=>za.getProfile(),staleTime:1800*1e3}),{data:O,isLoading:C}=J({queryKey:["kosp-config",e],queryFn:()=>xa.getConfigByTahun(e),enabled:!!e}),{data:_,isLoading:D}=J({queryKey:["kurikulum-struktur-all",e],queryFn:()=>ua.getStruktur({tahun_pelajaran_id:e}),enabled:!!e}),{data:i}=J({queryKey:["struktur-organisasi-tree-kosp"],queryFn:()=>Ba(),staleTime:1800*1e3}),{data:r}=J({queryKey:["kosp-kalender-akademik",e],queryFn:()=>ua.getKalenderAkademik(e),enabled:!!e,staleTime:600*1e3}),A=o.useMemo(()=>R||[],[R]),g=U?.data||null,f=O?.data||null,y=o.useMemo(()=>{if(f?.config)try{return typeof f.config=="string"?JSON.parse(f.config):f.config}catch{}return{}},[f]),j=o.useMemo(()=>y?.meta||{},[y]),M=o.useMemo(()=>k.find(b=>b.id===e)||K||null,[k,e,K]),L=o.useMemo(()=>M?.tahun||M?.nama||"2025/2026",[M]),s=o.useMemo(()=>_?.data||[],[_?.data]),c=i?.data||{},P=c.KEPALA_SEKOLAH?.[0]?.members?.[0],H=c.KURIKULUM?.[0]?.members?.[0],E=P?.name||g?.kepala_sekolah||"Kepala Sekolah",q=(P?.details||"").match(/NIP[:\s.]+([\d\s]+)/i)?.[1]?.trim()||g?.nip_kepala||"-",Y=H?.name||"Wakasek Kurikulum";(H?.details||"").match(/NIP[:\s.]+([\d\s]+)/i)?.[1]?.trim();const na=o.useMemo(()=>!m||m.length===0?'<p style="color:#64748b; font-style:italic;">Belum ada daftar jurusan terdaftar.</p>':m.map(b=>be(b,s)).join('<p class="mce-pagebreak" style="page-break-before: always;"><!-- pagebreak --></p>'),[m,s]),sa=o.useMemo(()=>{const b=Array.isArray(r?.data)?r.data:[];return ge(b)},[r]),ia=o.useMemo(()=>me(n),[n]),ra=o.useMemo(()=>ue(A||[]),[A]),oa=o.useMemo(()=>oe(g?.logo_url,g?.nama||"SMK"),[g?.logo_url,g?.nama]),la=o.useMemo(()=>le(E,Y,j.tim_penyusun,c),[E,Y,j.tim_penyusun,c]),da=o.useMemo(()=>de(),[]),pa=o.useMemo(()=>pe(),[]),ga=o.useMemo(()=>!m||m.length===0?"":`
      <ul style="margin:8px 0; padding-left:20px; font-size:11pt; line-height:1.6;">
        ${m.map(b=>`
          <li><strong>${b.nama}</strong> (${b.singkatan||b.kode||"JUR"})</li>
        `).join("")}
      </ul>
    `,[m]),Aa=o.useMemo(()=>{const b=f?.halaman_html?typeof f.halaman_html=="string"?JSON.parse(f.halaman_html):f.halaman_html:ha(),W=j.tanggal_sk?new Date(j.tanggal_sk).toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"}):new Date().toLocaleDateString("id-ID",{day:"numeric",month:"long",year:"numeric"}),h=S=>S==null?"":typeof S=="string"?S:typeof S=="number"||typeof S=="boolean"?String(S):"",F=(S,V)=>S&&S.trim()&&S!=="-"&&S!=="Kepala Sekolah"&&S!=="Wakasek Kurikulum"?h(S):`<span style="color:#dc2626; font-style:italic; font-weight:bold;">[⚠️ ${V}: Ketik langsung di sini ATAU atur via Pengaturan SK]</span>`,Sa={"{{NAMASEKOLAH}}":h(g?.nama||"[NAMA SEKOLAH BELUM DIISI]"),"{{TAHUNPELAJARAN}}":h(L),"{{KOTASEKOLAH}}":h(g?.kota||g?.kecamatan||"[KOTA SEKOLAH]"),"{{ALAMATSEKOLAH}}":h(g?.alamat||"[ALAMAT SEKOLAH]"),"{{NPSNSEKOLAH}}":h(g?.npsn||"[NPSN SEKOLAH]"),"{{LOGOSEKOLAH_HTML}}":h(oa),"{{TANGGALPENGESAHAN}}":h(W),"{{NAMAKETUAKOMITE}}":F(j?.komite_nama,"NAMA KETUA KOMITE"),"{{NAMAKEPALASEKOLAH}}":F(E,"NAMA KEPALA SEKOLAH"),"{{NIPKEPALASEKOLAH}}":h(q!=="-"?q:"[NIP KEPALA SEKOLAH]"),"{{NAMAKEPAKACABDIN}}":F(j?.kcd_nama,"NAMA KEPALA CABDIN"),"{{NIPKEPAKACABDIN}}":h(j?.kcd_nip||"[NIP KEPALA CABDIN]"),"{{KARAKTERISTIK_SEKOLAH}}":h(f?.karakteristik||`
        <p style="text-align:justify; font-size:11pt; line-height:1.6; color:#475569;">
          <em><span style="color:#dc2626; font-weight:bold;">[⚠️ KARAKTERISTIK SEKOLAH: Ketik langsung di sini ATAU atur via Database]</span> Deskripsi Karakteristik Satuan Pendidikan belum diisi. Anda dapat langsung mengetikkan paragraf gambaran umum sekolah Anda di sini persis seperti di Word.</em>
        </p>
      `),"{{DAFTAR_JURUSAN_SUMMARY}}":h(ga),"{{VISI_SEKOLAH}}":h(f?.visi||'<span style="color:#dc2626; font-style:italic; font-weight:bold;">[⚠️ VISI SEKOLAH: Ketik langsung teks visi sekolah Anda di sini ATAU atur via Database KOSP]</span>'),"{{MISI_SEKOLAH}}":h(f?.misi||'<p style="color:#dc2626; font-style:italic; font-weight:bold;">[⚠️ MISI SEKOLAH: Ketik langsung poin-poin misi sekolah Anda di sini ATAU atur via Database KOSP]</p>'),"{{TABEL_STRUKTUR_KURIKULUM_SEMUA_JURUSAN}}":h(na),"{{TABEL_KALENDER_PENDIDIKAN}}":h(sa),"{{TABEL_JAM_KBM}}":h(ia),"{{TABEL_DUDI_MITRA}}":h(ra),"{{TABEL_SK_TIM_PENYUSUN}}":h(la),"{{TABEL_P5_MATRIKS}}":h(da),"{{TABEL_ESKUL_MATRIKS}}":h(pa),"{{NOMOR_SK}}":F(j?.nomor_sk,"NOMOR SK KEPSEK"),"{{NAMA_DINAS_PROVINSI}}":h(j?.nama_dinas_provinsi||"[DINAS PENDIDIKAN PROVINSI BELUM DIISI]"),"{{NAMA_CABDIN}}":h(j?.nama_cabdin||"[CABANG DINAS PENDIDIKAN BELUM DIISI]")};return b.map((S,V)=>{let w=h(S.html);/BAB V:/i.test(w)&&!/<p[^>]*>.*?<!--\s*pagebreak\s*-->.*?<\/p>/i.test(w)&&(w=w.replace(/(<h[1-6][^>]*>[\s\S]*?BAB V:)/gi,`<p class="mce-pagebreak" style="page-break-before: always;"><!-- pagebreak --></p>
$1`)),/DAFTAR ISI/i.test(w)&&/KATA PENGANTAR/i.test(w)&&!/<p[^>]*>.*?<!--\s*pagebreak\s*-->.*?<\/p>/i.test(w)&&(w=w.replace(/(<h[1-6][^>]*>[\s\S]*?DAFTAR ISI)/gi,`<p class="mce-pagebreak" style="page-break-before: always;"><!-- pagebreak --></p>
$1`)),Object.entries(Sa).forEach(([Na,ja])=>{w=w.replaceAll(Na,ja)});const Pa=S.label&&!/^Halaman\s+\d+$/i.test(S.label.trim())?S.label:ka[V]||S.label||`Halaman ${V+1}`;return{...S,label:Pa,html:w}})},[f,g,L,E,q,oa,la,da,pa,ga,na,sa,ia,ra,j]),Q=o.useMemo(()=>({paperKey:y.paperKey||"A4",orientation:y.orientation||"portrait",margin:y.margin||{top:"2.5cm",right:"2.5cm",bottom:"2.5cm",left:"2.5cm"}}),[y]),$=Ra({mutationFn:b=>xa.upsertConfig({tahun_pelajaran_id:e,halaman_html:b.halaman_html,config:b.config}),onSuccess:()=>{t.invalidateQueries({queryKey:["kosp-config",e]}),ea.success(`Pengaturan KOSP TP ${L} berhasil disimpan ke database!`)},onError:()=>{ea.error("Gagal menyimpan pengaturan KOSP")}}),fa=o.useCallback(async(b,W)=>{const h={...y,...W||Q};await $.mutateAsync({halaman_html:JSON.stringify(b),config:JSON.stringify(h)})},[e,$,Q,y]),Ka=o.useCallback(async b=>{const W={...y,meta:b};await $.mutateAsync({config:JSON.stringify(W)})},[y,$]),ya=o.useCallback(async()=>{const b=ha();await $.mutateAsync({halaman_html:JSON.stringify(b)}),ea.success(`Naskah KOSP TP ${L} berhasil direset ke versi Template Master terbaru!`)},[L,$]);return{selectedTahunId:e,setSelectedTahunId:d,selectedTahunNama:L,tahunOptions:x,tahunList:k,jurusanList:m,sekolahInfo:g,isEditorOpen:u,setIsEditorOpen:p,isMetaModalOpen:N,setIsMetaModalOpen:l,metaConfigData:j,compiledPages:Aa,initialConfig:Q,isLoading:T||v||C||D||B,isSaving:$.isPending,handleSaveKospPages:fa,handleSaveMetaConfig:Ka,handleResetToMasterTemplate:ya,namaKepalaSekolah:E,wakasekKurikulum:Y,mappingAllDataCount:s.length,treeData:c}},he=X.memo(({isOpen:t,onClose:n,initialData:e,defaultKepsek:d,defaultWakasek:u,treeData:p,onSave:N,isSaving:l=!1})=>{const[x,k]=o.useState(""),[K,T]=o.useState(""),[m,v]=o.useState(""),[R,B]=o.useState(""),[U,O]=o.useState(""),[C,_]=o.useState(""),[D,i]=o.useState(""),[r,A]=o.useState([]),g=()=>[{no:1,nama:I(p,"KEPALA_SEKOLAH",d||"Kepala Sekolah"),jabatan_kedinasan:"Kepala Sekolah",jabatan_tim:"Penanggung Jawab"},{no:2,nama:I(p,"KURIKULUM",u||"Wakasek Kurikulum"),jabatan_kedinasan:"Wakasek Bidang Kurikulum",jabatan_tim:"Ketua Tim Penyusun"},{no:3,nama:"Pengawas Pembina Sekolah",jabatan_kedinasan:"Pengawas Pembina Sekolah",jabatan_tim:"Narasumber / Pendamping"},{no:4,nama:D||"Ketua Komite Sekolah",jabatan_kedinasan:"Ketua Komite Sekolah",jabatan_tim:"Narasumber Komite"},{no:5,nama:I(p,"KESISWAAN","Wakasek Bidang Kesiswaan"),jabatan_kedinasan:"Wakasek Kesiswaan",jabatan_tim:"Anggota / Tim Pengembang"},{no:6,nama:I(p,"HUBIN","Wakasek Bidang Humas & Hubin"),jabatan_kedinasan:"Wakasek Humas/DUDI",jabatan_tim:"Anggota / Tim Penyelaras DUDI"},{no:7,nama:I(p,"SARPRAS","Wakasek Bidang Sarana Prasarana"),jabatan_kedinasan:"Wakasek Sarpras",jabatan_tim:"Anggota / Tim Fasilitas"},{no:8,nama:I(p,"KAPROG","Para Ketua Program Keahlian (Kaprog)"),jabatan_kedinasan:"Kaprog Keahlian",jabatan_tim:"Anggota / Tim Kurikulum Jurusan"},{no:9,nama:I(p,"BPBK","Koor. Bimbingan Konseling (BK)"),jabatan_kedinasan:"Guru BK",jabatan_tim:"Anggota / Tim Asesmen & Karakter"},{no:10,nama:I(p,"TU_KEPALA","Koordinator Tata Usaha"),jabatan_kedinasan:"Kepala Tata Usaha",jabatan_tim:"Anggota / Tim Administrasi"}];o.useEffect(()=>{if(!t)return;k(e?.nomor_sk||""),T(e?.tanggal_sk||new Date().toISOString().split("T")[0]),v(e?.nama_dinas_provinsi||""),B(e?.nama_cabdin||""),O(e?.kcd_nama||""),_(e?.kcd_nip||""),i(e?.komite_nama||"");let s=[];if(e?.tim_penyusun&&e.tim_penyusun.length>0?s=e.tim_penyusun:s=g(),p&&Object.keys(p).length>0){const c={1:"KEPALA_SEKOLAH",2:"KURIKULUM",5:"KESISWAAN",6:"HUBIN",7:"SARPRAS",8:"KAPROG",9:"BPBK",10:"TU_KEPALA"};s=s.map(P=>{const H=c[P.no||0];if(H&&ta(P.nama)){const E=I(p,H,P.nama);if(E&&E!==P.nama&&!ta(E))return{...P,nama:E}}return P})}A(s)},[t,p]);const f=()=>{A(g())},y=()=>{A(s=>[...s,{no:s.length+1,nama:"",jabatan_kedinasan:"Guru Mata Pelajaran",jabatan_tim:"Anggota Tim Penyusun"}])},j=s=>{A(c=>c.filter((P,H)=>H!==s))},M=(s,c,P)=>{A(H=>{const E=[...H];return E[s]={...E[s],[c]:P},E})},L=async s=>{s.preventDefault();try{await N({nomor_sk:x,tanggal_sk:K,nama_dinas_provinsi:m,nama_cabdin:R,kcd_nama:U,kcd_nip:C,komite_nama:D,tim_penyusun:r.map((c,P)=>({...c,no:P+1}))}),n()}catch{}};return a.jsx(Ca,{isOpen:t,onClose:n,title:"⚙️ Pengaturan Legalitas & Tim Penyusun KOSP",maxWidth:"max-w-4xl",children:a.jsxs("form",{onSubmit:L,className:"space-y-5 py-2",children:[a.jsxs("div",{className:"bg-slate-50 dark:bg-slate-800/60 p-4 rounded-xl border border-slate-200 dark:border-slate-700 space-y-3",children:[a.jsxs("div",{className:"flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200 text-sm",children:[a.jsx($a,{className:"w-4 h-4 text-blue-600 dark:text-blue-400"}),a.jsx("span",{children:"Informasi SK Penetapan & Pengesahan KOSP"})]}),a.jsxs("div",{className:"grid grid-cols-1 sm:grid-cols-2 gap-3",children:[a.jsxs("div",{children:[a.jsx("label",{className:"block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1",children:"Nomor SK Kepsek"}),a.jsx(z,{value:x,onChange:s=>k(s.target.value),placeholder:"Contoh: 421.5/089/SK-KOSP/2025",required:!0})]}),a.jsxs("div",{children:[a.jsx("label",{className:"block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1",children:"Tanggal Penetapan SK"}),a.jsx(z,{type:"date",value:K,onChange:s=>T(s.target.value),required:!0})]}),a.jsxs("div",{className:"sm:col-span-2",children:[a.jsx("label",{className:"block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1",children:"Nama Dinas Pendidikan Provinsi"}),a.jsx(z,{value:m,onChange:s=>v(s.target.value),placeholder:"Contoh: Dinas Pendidikan Provinsi Jawa Barat"})]}),a.jsxs("div",{className:"sm:col-span-2",children:[a.jsx("label",{className:"block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1",children:"Nama Cabang Dinas Pendidikan (Cabdin)"}),a.jsx(z,{value:R,onChange:s=>B(s.target.value),placeholder:"Contoh: Cabang Dinas Pendidikan Wilayah VII"})]}),a.jsxs("div",{children:[a.jsx("label",{className:"block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1",children:"Nama Kepala Cabang Dinas (KCD)"}),a.jsx(z,{value:U,onChange:s=>O(s.target.value),placeholder:"Contoh: Drs. H. Mamat Rahmat, M.Si."})]}),a.jsxs("div",{children:[a.jsx("label",{className:"block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1",children:"NIP Kepala Cabang Dinas (KCD)"}),a.jsx(z,{value:C,onChange:s=>_(s.target.value),placeholder:"Contoh: 19680315 199303 1 008"})]}),a.jsxs("div",{className:"sm:col-span-2",children:[a.jsx("label",{className:"block text-xs font-semibold text-slate-600 dark:text-slate-300 mb-1",children:"Nama Ketua Komite Sekolah"}),a.jsx(z,{value:D,onChange:s=>i(s.target.value),placeholder:"Contoh: H. Dudung Abdurrahman, M.Pd."})]})]})]}),a.jsxs("div",{className:"space-y-3",children:[a.jsxs("div",{className:"flex items-center justify-between",children:[a.jsxs("div",{className:"flex items-center gap-2 font-bold text-slate-800 dark:text-slate-200 text-sm",children:[a.jsx(Ja,{className:"w-4 h-4 text-emerald-600 dark:text-emerald-400"}),a.jsxs("span",{children:["Susunan Tim Pengembang & Penyusun KOSP (",r.length," Orang)"]})]}),a.jsxs("div",{className:"flex items-center gap-2",children:[a.jsxs(G,{type:"button",variant:"outline",size:"sm",onClick:f,className:"text-xs",children:[a.jsx(Ga,{className:"w-3.5 h-3.5 mr-1"}),"Reset ke Default"]}),a.jsxs(G,{type:"button",size:"sm",onClick:y,className:"bg-blue-600 hover:bg-blue-700 text-white text-xs",children:[a.jsx(Wa,{className:"w-3.5 h-3.5 mr-1"}),"Tambah Anggota"]})]})]}),a.jsx("div",{className:"max-h-72 overflow-y-auto border border-slate-200 dark:border-slate-700 rounded-xl shadow-xs",children:a.jsxs("table",{className:"w-full text-xs border-collapse",children:[a.jsx("thead",{children:a.jsxs("tr",{className:"bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-300 font-bold border-b border-slate-200 dark:border-slate-700",children:[a.jsx("th",{className:"p-2.5 text-center w-10",children:"No"}),a.jsx("th",{className:"p-2.5 text-left",children:"Nama Personal"}),a.jsx("th",{className:"p-2.5 text-left",children:"Jabatan Kedinasan"}),a.jsx("th",{className:"p-2.5 text-left",children:"Tugas dalam Tim"}),a.jsx("th",{className:"p-2.5 text-center w-10",children:"Aksi"})]})}),a.jsx("tbody",{className:"divide-y divide-slate-200 dark:divide-slate-700",children:r.map((s,c)=>a.jsxs("tr",{className:"hover:bg-slate-50 dark:hover:bg-slate-800/50",children:[a.jsx("td",{className:"p-2 text-center font-bold text-slate-500",children:c+1}),a.jsx("td",{className:"p-2",children:a.jsx(z,{value:s.nama,onChange:P=>M(c,"nama",P.target.value),placeholder:"Nama Lengkap & Gelar",className:"text-xs py-1 h-8",required:!0})}),a.jsx("td",{className:"p-2",children:a.jsx(z,{value:s.jabatan_kedinasan,onChange:P=>M(c,"jabatan_kedinasan",P.target.value),placeholder:"Jabatan Kedinasan",className:"text-xs py-1 h-8"})}),a.jsx("td",{className:"p-2",children:a.jsx(z,{value:s.jabatan_tim,onChange:P=>M(c,"jabatan_tim",P.target.value),placeholder:"Tugas Tim KOSP",className:"text-xs py-1 h-8"})}),a.jsx("td",{className:"p-2 text-center",children:a.jsx("button",{type:"button",onClick:()=>j(c),className:"p-1 text-slate-400 hover:text-rose-600 transition-colors",title:"Hapus",children:a.jsx(Fa,{className:"w-4 h-4"})})})]},`tim-${c}-${s.nama||c}`))})]})})]}),a.jsxs("div",{className:"flex items-center justify-end gap-2 pt-3 border-t border-slate-200 dark:border-slate-700",children:[a.jsx(G,{type:"button",variant:"outline",onClick:n,children:"Batal"}),a.jsx(G,{type:"submit",isLoading:l,className:"bg-blue-600 hover:bg-blue-700 text-white",children:"Simpan Pengaturan"})]})]})})}),ce=o.lazy(()=>La(()=>import("./KospWordEditorModal-DlvCVgvM.js"),__vite__mapDeps([0,1,2,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29]))),Ze=X.memo(()=>{const{isKurikulum:t,isKepsek:n,isAdmin:e,can:d}=Ea();e||t||n||d("academic.manage.academic");const[u,p]=X.useState(0),N=ie(),{selectedTahunId:l,setSelectedTahunId:x,selectedTahunNama:k,jurusanList:K,sekolahInfo:T,isEditorOpen:m,setIsEditorOpen:v,isMetaModalOpen:R,setIsMetaModalOpen:B,metaConfigData:U,compiledPages:O,initialConfig:C,isSaving:_,handleSaveKospPages:D,handleSaveMetaConfig:i,handleResetToMasterTemplate:r,namaKepalaSekolah:A,wakasekKurikulum:g,mappingAllDataCount:f,treeData:y}=xe(),j=X.useMemo(()=>[{label:"Kurikulum"},{label:"Generator KOSP"}],[]),M=(s=0)=>{p(s),v(!0)},L=async()=>{await N({title:`Reset KOSP TP ${k} ke Template Master Baru`,description:`Apakah Anda yakin ingin memuat ulang naskah dokumen KOSP TP ${k} ke susunan Template Master resmi terbaru?

Catatan: Suntingan manual sebelumnya pada draf dokumen ini akan digantikan dengan susunan bab master resmi terbaru (Bab IV, Bab V, Daftar Isi & Pemisah Halaman Per-Jurusan).`,confirmText:"Ya, Reset ke Template Master",cancelText:"Batal",style:"danger"})&&await r()};return a.jsx(wa,{title:"Generator KOSP (Kurikulum Operasional Satuan Pendidikan)",description:"Penyusunan dokumen KOSP otomatis dan live berbasis Word Style per Tahun Pelajaran.",breadcrumbs:j,hardeningModuleKey:"kospbuilderpage",instruction:{title:"Panduan Modul KOSP Builder",description:"Modul ini merangkum data live profil sekolah, struktur kurikulum semua jurusan, dan kalender pendidikan menjadi dokumen resmi KOSP.",items:[{text:"Pilih Tahun Pelajaran yang ingin disusun dokumen KOSP-nya."},{text:'Atur Legalitas SK & Tim Penyusun melalui tombol "Pengaturan Legalitas SK & Tim".'},{text:'Jika membuka draf lama, gunakan tombol "Reset ke Template Master Baru" untuk memperbarui struktur halaman resmi KOSP.'},{text:"Klik pada kartu Bab/Halaman untuk langsung menuju dan menyunting naskah Bab tersebut."},{text:"Data Struktur Kurikulum semua jurusan otomatis disuntikkan dari database Absenta sesuai regulasi Kemendikbud."},{text:"Simpan atau langsung cetak dokumen ke format PDF/Word."}]},children:a.jsxs("div",{className:"space-y-6 animate-in fade-in duration-500 pb-20",children:[a.jsxs("div",{className:"flex flex-col md:flex-row md:items-center justify-between gap-4 bg-white dark:bg-slate-900 p-4 rounded-2xl border border-gray-100 dark:border-gray-800 shadow-sm",children:[a.jsxs("div",{className:"flex items-center gap-3",children:[a.jsx("div",{className:"p-3 bg-indigo-50 dark:bg-indigo-950/40 text-indigo-600 dark:text-indigo-400 rounded-xl",children:a.jsx(Va,{size:24})}),a.jsxs("div",{children:[a.jsxs("h2",{className:"text-lg font-black text-gray-900 dark:text-white uppercase tracking-tight",children:["Dokumen KOSP TP ",k]}),a.jsx("p",{className:"text-xs text-gray-500 font-medium",children:"Patuh Kepmendikbudristek No. 262/M/2022"})]})]}),a.jsxs("div",{className:"flex flex-wrap items-center gap-3",children:[a.jsxs("div",{className:"flex items-center gap-2 bg-slate-100 dark:bg-slate-800 px-3 py-1.5 rounded-xl",children:[a.jsx(Xa,{size:15,className:"text-gray-400"}),a.jsx("span",{className:"text-xs font-bold text-gray-500",children:"Tahun Pelajaran:"}),a.jsx(va,{value:l,onValueChange:x,placeholder:"Pilih Tahun...",className:"bg-transparent border-none text-xs font-black focus:ring-0 cursor-pointer min-w-[145px] max-w-full [&>button]:bg-transparent [&>button]:border-none [&>button]:focus:ring-0"})]}),a.jsxs(G,{variant:"outline",onClick:()=>B(!0),className:"rounded-xl flex items-center gap-2 border-slate-300 dark:border-slate-700 text-xs font-bold h-11",children:[a.jsx(qa,{size:16,className:"text-blue-600 dark:text-blue-400"}),"Pengaturan SK & Tim Penyusun"]}),a.jsxs(G,{variant:"outline",onClick:L,disabled:_,className:"rounded-xl flex items-center gap-2 border-amber-300 hover:bg-amber-50 dark:border-amber-900/60 dark:hover:bg-amber-950/40 text-amber-700 dark:text-amber-400 text-xs font-bold h-11",title:"Reset susunan dokumen ke Template Master Resmi Terbaru",children:[a.jsx(Ya,{size:15,className:"text-amber-600 dark:text-amber-400"}),"Reset ke Template Master Baru"]}),a.jsxs(G,{onClick:()=>M(0),className:"bg-indigo-600 hover:bg-indigo-700 text-white font-black rounded-xl shadow-lg shadow-indigo-200 dark:shadow-none flex items-center gap-2 px-4 h-11",children:[a.jsx(Qa,{size:16}),"BUKA LIVE WORD EDITOR KOSP",a.jsx(Za,{size:16})]})]})]}),a.jsxs("div",{className:"grid grid-cols-1 md:grid-cols-3 gap-6",children:[a.jsxs(Z,{className:"p-6 bg-gradient-to-br from-indigo-50/50 via-white to-purple-50/30 dark:from-indigo-950/20 dark:via-slate-900 dark:to-purple-950/10 border-indigo-100 dark:border-indigo-900/50 shadow-sm relative overflow-hidden",children:[a.jsx("div",{className:"absolute top-0 right-0 p-4 text-indigo-200 dark:text-indigo-900/30",children:a.jsx(ae,{size:80,strokeWidth:1})}),a.jsxs("div",{className:"relative z-10 space-y-3",children:[a.jsx(aa,{variant:"outline",className:"bg-indigo-100 dark:bg-indigo-900/60 text-indigo-700 dark:text-indigo-300 border-indigo-200",children:"Profil Satuan Pendidikan"}),a.jsx("h3",{className:"text-xl font-bold text-gray-900 dark:text-white",children:T?.nama||"SMK NEGERI 1 PLERED"}),a.jsxs("div",{className:"space-y-1 text-xs text-gray-600 dark:text-gray-400",children:[a.jsxs("p",{children:[a.jsx("strong",{children:"Kepala Sekolah:"})," ",A]}),a.jsxs("p",{children:[a.jsx("strong",{children:"Wakasek Kurikulum:"})," ",g]}),a.jsxs("p",{children:[a.jsx("strong",{children:"Status Pengesahan:"})," Siap Ditetapkan"]})]})]})]}),a.jsxs(Z,{className:"p-6 bg-gradient-to-br from-emerald-50/50 via-white to-teal-50/30 dark:from-emerald-950/20 dark:via-slate-900 dark:to-teal-950/10 border-emerald-100 dark:border-emerald-900/50 shadow-sm relative overflow-hidden",children:[a.jsx("div",{className:"absolute top-0 right-0 p-4 text-emerald-200 dark:text-emerald-900/30",children:a.jsx(ee,{size:80,strokeWidth:1})}),a.jsxs("div",{className:"relative z-10 space-y-3",children:[a.jsx(aa,{variant:"outline",className:"bg-emerald-100 dark:bg-emerald-900/60 text-emerald-700 dark:text-emerald-300 border-emerald-200",children:"Agregasi Data Struktur Kurikulum"}),a.jsxs("div",{className:"flex items-baseline gap-2",children:[a.jsx("span",{className:"text-3xl font-black text-emerald-600 dark:text-emerald-400",children:K?.length||0}),a.jsx("span",{className:"text-sm font-bold text-gray-700 dark:text-gray-300",children:"Jurusan Terkoneksi"})]}),a.jsxs("p",{className:"text-xs text-gray-600 dark:text-gray-400",children:["Menghubungkan ",f," entri mata pelajaran live untuk seluruh konsentrasi keahlian."]})]})]}),a.jsxs(Z,{className:"p-6 bg-gradient-to-br from-blue-50/50 via-white to-cyan-50/30 dark:from-blue-950/20 dark:via-slate-900 dark:to-cyan-950/10 border-blue-100 dark:border-blue-900/50 shadow-sm relative overflow-hidden",children:[a.jsx("div",{className:"absolute top-0 right-0 p-4 text-blue-200 dark:text-blue-900/30",children:a.jsx(te,{size:80,strokeWidth:1})}),a.jsxs("div",{className:"relative z-10 space-y-3",children:[a.jsx(aa,{variant:"outline",className:"bg-blue-100 dark:bg-blue-900/60 text-blue-700 dark:text-blue-300 border-blue-200",children:"Legalitas SK & Tim Penyusun"}),a.jsxs("div",{className:"flex items-baseline gap-2",children:[a.jsx("span",{className:"text-3xl font-black text-blue-600 dark:text-blue-400",children:U?.tim_penyusun?.length||9}),a.jsx("span",{className:"text-sm font-bold text-gray-700 dark:text-gray-300",children:"Personel Tim Penyusun"})]}),a.jsxs("p",{className:"text-xs text-gray-600 dark:text-gray-400 truncate",children:["SK Kepsek: ",a.jsx("strong",{children:U?.nomor_sk||"[BELUM DIISI]"})]})]})]})]}),a.jsxs("div",{className:"space-y-4",children:[a.jsxs("div",{className:"flex items-center justify-between",children:[a.jsxs("h3",{className:"text-base font-bold text-gray-900 dark:text-white flex items-center gap-2",children:[a.jsx(ne,{size:18,className:"text-indigo-600"}),"Struktur Bab & Halaman Naskah KOSP (",O.length," Halaman / Bab)"]}),a.jsx("span",{className:"text-xs text-gray-500 font-medium",children:"Klik pada kartu bab untuk langsung menuju & menyunting bab tersebut."})]}),a.jsx("div",{className:"grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4",children:O?.map((s,c)=>a.jsxs("div",{onClick:()=>M(c),className:"group p-4 bg-white dark:bg-slate-900 rounded-xl border border-gray-200 dark:border-gray-800 hover:border-indigo-500 dark:hover:border-indigo-500 shadow-xs hover:shadow-md transition-all duration-200 cursor-pointer flex flex-col justify-between h-40",children:[a.jsxs("div",{children:[a.jsxs("div",{className:"flex items-center justify-between mb-2",children:[a.jsxs("span",{className:"text-[10px] font-black tracking-wider uppercase px-2 py-0.5 rounded-full bg-slate-100 dark:bg-slate-800 text-slate-600 dark:text-slate-400",children:["HALAMAN ",c+1]}),a.jsx(se,{size:14,className:"text-emerald-500"})]}),a.jsx("h4",{className:"font-bold text-sm text-gray-900 dark:text-white group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-colors line-clamp-2",children:s.label})]}),a.jsxs("div",{className:"text-[11px] text-gray-500 font-medium flex items-center justify-between pt-2 border-t border-gray-100 dark:border-gray-800",children:[a.jsx("span",{className:"text-indigo-600 dark:text-indigo-400 font-semibold group-hover:underline",children:"Sunting Bab Ini"}),a.jsx("span",{className:"group-hover:translate-x-1 transition-transform text-indigo-600 dark:text-indigo-400 font-bold",children:"→"})]})]},s.label||`kosp-page-${c}`))})]}),a.jsx(he,{isOpen:R,onClose:()=>B(!1),initialData:U,defaultKepsek:A,defaultWakasek:g,treeData:y,onSave:i,isSaving:_}),m&&a.jsx(o.Suspense,{fallback:a.jsx(Ma,{text:"Memuat Word Editor KOSP..."}),children:a.jsx(ce,{isOpen:m,onClose:()=>v(!1),documentTitle:`Dokumen KOSP ${T?.nama||""} TP ${k}`,pages:O,initialPageIndex:u,initialConfig:C,onSavePages:D,isSaving:_})})]})})});export{Ze as KospBuilderPage,Ze as default};
