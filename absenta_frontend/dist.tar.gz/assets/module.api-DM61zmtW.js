import{a1 as e}from"./index-RCmYd9zv.js";async function t(){return e("get","/billing/modules/public")}export{t as g};
