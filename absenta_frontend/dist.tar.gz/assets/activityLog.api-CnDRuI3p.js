import{a1 as a}from"./index-RCmYd9zv.js";const s=async t=>a("get","/activity-logs",{params:t});export{s as g};
