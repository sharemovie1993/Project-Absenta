import{j as r}from"./vendor-query-BhgjtrJT.js";import{l as x}from"./vendor-react-BFl1Q6nk.js";import{P as b}from"./PrintableCard-DtXNgI43.js";import"./browser-CxMnavuI.js";import"./constants-69F4QYMX.js";import"./main-CUbVbX1E.js";import"./index-B6EsGKGr.js";import"./vendor-date-_usxnDfA.js";import"./vendor-ui-libs-Cq6TYVVI.js";import"./vendor-utils-fU52AciR.js";import"./vendor-framer-B_CzOjsy.js";import"./CardPatternLayer-CTzhyJzA.js";const F=({isPrinting:l,pages:a,printLayout:t,printConfig:e,config:s,sekolah:p})=>l?x.createPortal(r.jsxs(r.Fragment,{children:[r.jsx("style",{children:`
                @media print {
                    @page {
                        size: ${e.paperSize==="RFID"?e.orientation==="portrait"?"54mm 85.6mm":"85.6mm 54mm":e.paperSize==="Custom"?"auto":e.paperSize} ${e.paperSize==="RFID"?"":e.orientation};
                        margin: 0;
                    }
                    body {
                        margin: 0 !important;
                        padding: 0 !important;
                        -webkit-print-color-adjust: exact;
                    }
                    body > * {
                        display: none !important;
                    }
                    body > #print-card-overlay-portal {
                        display: block !important;
                        position: fixed !important;
                        inset: 0 !important;
                        background: white !important;
                        z-index: 99999 !important;
                    }
                }
                `}),r.jsx("div",{id:"print-card-overlay-portal",className:"fixed inset-0 bg-white z-[9999] print:block hidden",children:a.map((d,i)=>r.jsx("div",{className:"relative w-full h-full",style:{width:`${t.finalW}mm`,height:`${t.finalH}mm`,pageBreakAfter:i<a.length-1?"always":"auto"},children:d.map((m,o)=>{const c=o%t.cols,n=Math.floor(o/t.cols),h=t.effectiveMarginLeft+c*(t.cardW+e.gapX),f=t.effectiveMarginTop+n*(t.cardH+e.gapY);return r.jsx("div",{style:{position:"absolute",left:`${h}mm`,top:`${f}mm`,width:`${t.cardW}mm`,height:`${t.cardH}mm`},children:r.jsx(b,{student:m,config:s,sekolah:p})},m.id)})},i))})]}),document.body):null;export{F as PrintOverlay};
