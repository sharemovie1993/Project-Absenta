import{O as e}from"./main-CUbVbX1E.js";const t={getProfile:async()=>e("get","/sekolah/me")};export{t as s};
