import{a1 as t}from"./index-RCmYd9zv.js";const a=async()=>t("get","/academic/stats",{headers:{"X-Skip-403-Redirect":"true"}});export{a as g};
