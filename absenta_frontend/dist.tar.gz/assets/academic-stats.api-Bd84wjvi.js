import{O as t}from"./main-CUbVbX1E.js";const a=async()=>t("get","/academic/stats",{headers:{"X-Skip-403-Redirect":"true"}});export{a as g};
