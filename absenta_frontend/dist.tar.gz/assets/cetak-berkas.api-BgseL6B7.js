import{O as e}from"./main-CUbVbX1E.js";const r=async()=>e("get","/academic/prep-checklist",{headers:{"X-Skip-403-Redirect":"true"}});export{r as g};
