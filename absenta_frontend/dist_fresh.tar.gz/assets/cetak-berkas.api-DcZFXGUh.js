import{t as e}from"./time-Cg-B9fJm.js";const r=async()=>e("get","/academic/prep-checklist",{headers:{"X-Skip-403-Redirect":"true"}});export{r as g};
