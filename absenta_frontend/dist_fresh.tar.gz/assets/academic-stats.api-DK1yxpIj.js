import{t}from"./time-Cg-B9fJm.js";const a=async()=>t("get","/academic/stats",{headers:{"X-Skip-403-Redirect":"true"}});export{a as g};
