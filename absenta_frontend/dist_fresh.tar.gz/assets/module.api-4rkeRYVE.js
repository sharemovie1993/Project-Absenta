import{t}from"./time-Cg-B9fJm.js";async function l(){return t("get","/billing/modules/public")}export{l as g};
