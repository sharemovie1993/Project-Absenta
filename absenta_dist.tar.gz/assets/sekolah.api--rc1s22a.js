import{t as e}from"./index-B2K_jJAZ.js";const s={getProfile:async()=>e("get","/sekolah/me"),updateSKWaliKelasTemplate:async a=>e("put","/sekolah/me",{data:{sk_wali_kelas_template:a}})};export{s};
