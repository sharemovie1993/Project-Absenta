import{b5 as i}from"./main-B0QaNgQh.js";function e(){const{confirm:o,setConfirmLoading:n}=i();return Object.assign(s=>o(s),{setLoading:n})}export{e as u};
