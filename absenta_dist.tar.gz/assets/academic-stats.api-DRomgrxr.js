import{t}from"./index-B2K_jJAZ.js";const a=async()=>t("get","/academic/stats",{headers:{"X-Skip-403-Redirect":"true"}});export{a as g};
