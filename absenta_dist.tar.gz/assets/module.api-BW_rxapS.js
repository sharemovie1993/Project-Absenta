import{t}from"./index-B2K_jJAZ.js";async function l(){return t("get","/billing/modules/public")}export{l as g};
