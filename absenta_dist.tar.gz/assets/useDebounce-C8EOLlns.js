import{r as o}from"./vendor-react-BFl1Q6nk.js";function c(e,t){const[r,u]=o.useState(e);return o.useEffect(()=>{const n=setTimeout(()=>{u(e)},t);return()=>{clearTimeout(n)}},[e,t]),r}export{c as u};
