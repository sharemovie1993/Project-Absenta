import{t as e}from"./index-B2K_jJAZ.js";const r=async()=>e("get","/academic/prep-checklist",{headers:{"X-Skip-403-Redirect":"true"}});export{r as g};
